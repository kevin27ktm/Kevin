
export enum Language {
  ENGLISH = 'en',
  MALAYALAM = 'ml',
}

export interface User {
  id: string;
  email: string;
  displayName?: string;
  createdAt: string; // ISO Date string
}

export interface BibleBook {
  id: string;
  name: string;
  nameMl: string;
  chapters: BibleChapter[];
  testament: 'OT' | 'NT';
}

export interface BibleChapter {
  id: string;
  chapterNumber: number;
}

export enum QuizType {
  PERSONAL = 'PERSONAL',
  GROUP = 'GROUP',
}

export enum QuizDifficulty {
  EASY = 'easy',
  MEDIUM = 'medium',
  HARD = 'hard',
  MIXED = 'mixed',
}

export interface QuizConfig {
  books: string[]; // Array of BibleBook ids
  chapters: Record<string, number[]>; // bookId: chapterNumbers[]
  numberOfQuestions: number;
  quizLanguage: Language;
  difficulty?: QuizDifficulty; // Optional for personal, required for group
  quizType?: QuizType; // To distinguish between personal and group
}

export interface AnswerOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: string;
  text: string;
  reference?: string; // e.g., "Genesis 1:1"
  options: AnswerOption[];
  points: number; // Points for this question
}

export interface QuizAttempt {
  id: string;
  userId?: string; // For tracking who took the quiz
  quizType: QuizType;
  groupQuizId?: string; // If it's a group quiz
  config: QuizConfig;
  questions: Question[];
  answers: Record<string, string>; // questionId: selectedAnswerId or "timeout"
  score: number;
  timeTaken: number; // seconds
  accuracy: number; // Percentage
  completedAt: string; // ISO Date string
}

export interface GroupQuiz {
  id: string;
  title: string;
  description?: string;
  creatorId: string; // User ID
  quizLanguage: Language;
  config: QuizConfig; // Contains books, chapters, numQuestions, difficulty
  difficulty: QuizDifficulty;
  startTime: string; // ISO Date string
  endTime: string; // ISO Date string
  totalDurationSeconds: number; // Calculated: numQuestions * 30s
  pointsPerCorrect: number;
  negativeMarkingEnabled: boolean;
  negativePointsPerIncorrect?: number;
  status: 'scheduled' | 'active' | 'completed' | 'cancelled';
  accessLink?: string; // Unique shareable link (conceptual for now)
  createdAt: string; // ISO Date string
  updatedAt: string; // ISO Date string
  // For localStorage, we might store participant summary here if needed
  participants?: Pick<QuizParticipant, 'userId' | 'score' | 'displayName'>[];
}

export interface QuizParticipant {
  id: string; // participant attempt id
  groupQuizId: string;
  userId: string;
  displayName?: string; // User's display name at the time of joining
  joinedAt: string; // ISO Date string
  score: number;
  answers: Record<string, string>; // questionId: selectedAnswerId or "timeout"
  timeTakenSeconds: number;
  status: 'not_started' | 'in_progress' | 'completed';
  completedAt?: string; // ISO Date string
}


export interface TranslationSet {
  [key: string]: string;
}

export interface Translations {
  [Language.ENGLISH]: TranslationSet;
  [Language.MALAYALAM]: TranslationSet;
}


import { QuizConfig, Question, Language, QuizDifficulty } from '../types';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { BIBLE_BOOKS_DATA } from '../utils/bibleData'; // To get book names for the prompt
import { UI_STRINGS_KEYS } from '../constants'; // For error messages potentially

// Initialize the Google GenAI client
const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

const CACHE_PREFIX = 'quizlib-';
const CACHE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

interface CachedQuizData {
  timestamp: number;
  questions: Question[];
}

const getCacheKey = (config: QuizConfig): string => {
  const { books, chapters, numberOfQuestions, quizLanguage, difficulty } = config;
  const sortedBookIds = [...books].sort().join(',');

  const chapterStrings: string[] = [];
  for (const bookId of [...books].sort()) { 
    if (chapters[bookId] && chapters[bookId].length > 0) {
      const sortedChapters = [...chapters[bookId]].sort((a, b) => a - b).join(',');
      chapterStrings.push(`${bookId}:${sortedChapters}`);
    }
  }
  const chapterKey = chapterStrings.join(';');
  const difficultyKey = difficulty || QuizDifficulty.MIXED;

  return `${CACHE_PREFIX}${quizLanguage}-${difficultyKey}-${sortedBookIds}-${chapterKey}-${numberOfQuestions}q`;
};


export const quizService = {
  generateQuizQuestions: async (config: QuizConfig): Promise<Question[]> => {
    console.log("Generating quiz with config:", config);

    const cacheKey = getCacheKey(config);
    try {
      const cachedItem = localStorage.getItem(cacheKey);
      if (cachedItem) {
        const parsedItem: CachedQuizData = JSON.parse(cachedItem);
        if (Date.now() - parsedItem.timestamp < CACHE_EXPIRY_MS) {
          console.log("Returning cached questions for key:", cacheKey);
          return parsedItem.questions;
        } else {
          localStorage.removeItem(cacheKey);
          console.log("Removed stale cache for key:", cacheKey);
        }
      }
    } catch (e) {
      console.warn("Error accessing or parsing cache:", e);
      localStorage.removeItem(cacheKey); 
    }

    const selectedBookNames = config.books.map(bookId => {
      const bookData = BIBLE_BOOKS_DATA.find(b => b.id === bookId);
      return config.quizLanguage === Language.ENGLISH ? bookData?.name : bookData?.nameMl;
    }).filter(Boolean).join(', ');

    if (!selectedBookNames) {
      console.error("No valid book names found for the selected book IDs:", config.books);
      throw new Error("Invalid book selection in configuration.");
    }
    
    let chapterDetails = "";
    const relevantChapterEntries = config.books.reduce((acc, bookId) => {
        if (config.chapters[bookId] && config.chapters[bookId].length > 0) {
            const bookData = BIBLE_BOOKS_DATA.find(b => b.id === bookId);
            const bookName = config.quizLanguage === Language.ENGLISH ? bookData?.name : bookData?.nameMl;
            if (bookName) {
                acc.push(`${bookName} chapters: ${config.chapters[bookId].join(', ')}`);
            }
        }
        return acc;
    }, [] as string[]);

    if (relevantChapterEntries.length > 0) {
        chapterDetails = `Focus on the following chapters if specified: ${relevantChapterEntries.join('; ')}. If no chapters are specified for a book, you can pick any chapter from that book.`;
    } else {
        chapterDetails = "You can pick any relevant chapters from the selected books.";
    }

    const difficultyInstruction = `The difficulty of questions should be ${config.difficulty || QuizDifficulty.MIXED}.`;

    const prompt = `Generate ${config.numberOfQuestions} multiple-choice Bible quiz questions in ${config.quizLanguage === Language.ENGLISH ? 'English' : 'Malayalam'}.
Each question should be based on the following Bible books: ${selectedBookNames}.
${difficultyInstruction}
${chapterDetails}
Each question should have 4 answer options. Only one option should be correct.
Provide the scripture reference for each question (e.g., "Genesis 1:1" or "ഉല്പത്തി 1:1").
Return the response as a JSON array of objects. Each object in the array should strictly follow this structure:
{
  "id": "a_unique_string_identifier_for_the_question_e.g_q123",
  "text": "The question text in ${config.quizLanguage === Language.ENGLISH ? 'English' : 'Malayalam'}",
  "reference": "The scripture reference as a string e.g. John 3:16",
  "options": [
    { "id": "option_1", "text": "Answer option 1 text", "isCorrect": true_or_false_boolean_value },
    { "id": "option_2", "text": "Answer option 2 text", "isCorrect": true_or_false_boolean_value },
    { "id": "option_3", "text": "Answer option 3 text", "isCorrect": true_or_false_boolean_value },
    { "id": "option_4", "text": "Answer option 4 text", "isCorrect": true_or_false_boolean_value }
  ],
  "points": 10 
}
Ensure that for each question, exactly one option has "isCorrect": true. The 'points' value should always be 10.
Do not include any explanations or introductory text outside the JSON array itself.
The entire response should be only the JSON array. Make sure the JSON is well-formed.`;

    try {
      console.log("Sending prompt to Gemini API:", prompt);
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
        config: { responseMimeType: "application/json" } 
      });

      let jsonStr = response.text.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) {
        jsonStr = match[2].trim();
      }

      console.log("Received raw JSON string from API:", jsonStr);
      const fetchedQuestions = JSON.parse(jsonStr) as Question[];
      
      if (!Array.isArray(fetchedQuestions) || fetchedQuestions.length === 0) {
        console.error("API returned an empty or invalid array of questions.");
        return []; 
      }
      
      const questionsWithFallbackIds = fetchedQuestions.map((q, index) => ({
        ...q,
        id: q.id || `gen_q_${Date.now()}_${index}`,
        points: q.points || 10, // Ensure points are set, default to 10 if not provided by AI
        options: q.options.map((opt, optIndex) => ({
            ...opt,
            id: opt.id || `opt_${index}_${optIndex}`
        }))
      }));

      try {
        const dataToCache: CachedQuizData = {
          timestamp: Date.now(),
          questions: questionsWithFallbackIds,
        };
        localStorage.setItem(cacheKey, JSON.stringify(dataToCache));
        console.log("Cached questions for key:", cacheKey);
      } catch (e) {
        console.warn("Error saving to cache (possibly full):", e);
      }

      return questionsWithFallbackIds;

    } catch (error) {
      console.error("Error generating quiz from Gemini API:", error);
      // Try to return a translated error message if possible
      // This key needs to be in constants.ts and TRANSLATIONS
      throw new Error(UI_STRINGS_KEYS.failedToGenerateQuiz); 
    }
  },
};


import React, { useState, ReactNode } from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { LocalizationProvider, useLocalization } from './hooks/useLocalization';
import { LoginScreen } from './components/Auth/LoginScreen';
import { SignupScreen } from './components/Auth/SignupScreen';
import { ProfileScreen } from './components/Profile/ProfileScreen';
import { DashboardScreen } from './components/Dashboard/DashboardScreen';
import { PersonalQuizCustomizationScreen } from './components/Quiz/QuizCustomizationScreen'; // Renamed
import { QuizPlayScreen } from './components/Quiz/QuizPlayScreen'; // This is for Personal Quiz
import { QuizResultsScreen } from './components/Quiz/QuizResultsScreen';
import { CreateGroupQuizScreen } from './components/Quiz/Group/CreateGroupQuizScreen'; // New
import { MyCreatedQuizzesScreen } from './components/Quiz/Group/MyCreatedQuizzesScreen'; // New
import { InvitedQuizzesScreen } from './components/Quiz/Group/InvitedQuizzesScreen'; // New
import { GroupQuizPlayScreen } from './components/Quiz/Group/GroupQuizPlayScreen'; // New
import { GroupQuizPreJoinScreen } from './components/Quiz/Group/GroupQuizPreJoinScreen'; // New
import { QuizConfig, QuizAttempt, Language, GroupQuiz, QuizType } from './types';
import { LoadingSpinner } from './components/Shared/LoadingSpinner';
import { UI_STRINGS_KEYS } from './constants';


interface ProtectedRouteProps {
  children?: ReactNode;
}
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  const { translate } = useLocalization();

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-light-bg">
        <LoadingSpinner text={translate(UI_STRINGS_KEYS.loading)} size="lg" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children ? <>{children}</> : <Outlet />;
};


const AppContent: React.FC = () => {
  const { language } = useLocalization();
  const navigate = useNavigate();
  
  // State for Personal Quiz Flow
  const [currentPersonalQuizConfig, setCurrentPersonalQuizConfig] = useState<QuizConfig | null>(null);
  const [lastPersonalQuizAttempt, setLastPersonalQuizAttempt] = useState<QuizAttempt | null>(null);

  // State for Group Quiz Flow (Participant)
  const [currentGroupQuiz, setCurrentGroupQuiz] = useState<GroupQuiz | null>(null); // For participant joining
  const [lastGroupQuizAttempt, setLastGroupQuizAttempt] = useState<QuizAttempt | null>(null);


  const handleStartPersonalQuiz = (config: QuizConfig) => {
    config.quizType = QuizType.PERSONAL;
    setCurrentPersonalQuizConfig(config);
    navigate('/quiz/personal/play');
  };
  
  const handleStartDefaultPersonalQuiz = () => {
    // Default config will be set in QuizPlayScreen if currentPersonalQuizConfig is null
    setCurrentPersonalQuizConfig(null); 
    navigate('/quiz/personal/play');
  };

  const handlePersonalQuizComplete = (attempt: QuizAttempt) => {
    attempt.quizType = QuizType.PERSONAL;
    setLastPersonalQuizAttempt(attempt);
    // Store attempt in local storage
     try {
        const attemptsStr = localStorage.getItem('bibleQuizAppQuizAttempts');
        const attempts = attemptsStr ? JSON.parse(attemptsStr) : [];
        attempts.push(attempt);
        localStorage.setItem('bibleQuizAppQuizAttempts', JSON.stringify(attempts));
    } catch(e) { console.error("Error saving personal quiz attempt", e); }
    navigate('/quiz/personal/results');
  };

  // Group Quiz Creator Flow
  const handleGroupQuizCreated = (groupQuiz: GroupQuiz) => {
    // For now, navigate to My Created Quizzes, later maybe a share modal
    navigate('/my-created-quizzes');
  };

  // Group Quiz Participant Flow
  const handleJoinGroupQuiz = (groupQuiz: GroupQuiz) => {
    setCurrentGroupQuiz(groupQuiz);
    navigate(`/quiz/group/play/${groupQuiz.id}`);
  };

  const handleGroupQuizComplete = (attempt: QuizAttempt) => {
    attempt.quizType = QuizType.GROUP;
    setLastGroupQuizAttempt(attempt);
     try {
        const attemptsStr = localStorage.getItem('bibleQuizAppQuizAttempts');
        const attempts = attemptsStr ? JSON.parse(attemptsStr) : [];
        attempts.push(attempt);
        localStorage.setItem('bibleQuizAppQuizAttempts', JSON.stringify(attempts));
    } catch(e) { console.error("Error saving group quiz attempt", e); }
    navigate(`/quiz/group/results/${attempt.id}`); // attempt ID can be used to fetch later
  };
  
  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';

  return (
    <div className={`app-container ${currentFontClass}`}>
      <Routes>
        {/* Auth Routes */}
        <Route path="/login" element={<LoginScreen />} />
        <Route path="/signup" element={<SignupScreen />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route 
            path="/" 
            element={<DashboardScreen onStartDefaultQuiz={handleStartDefaultPersonalQuiz} />} 
          />
          <Route path="/profile" element={<ProfileScreen />} />

          {/* Personal Quiz Routes */}
          <Route 
            path="/quiz/personal/customize" 
            element={<PersonalQuizCustomizationScreen onStartQuiz={handleStartPersonalQuiz} />} 
          />
          <Route 
            path="/quiz/personal/play" 
            element={
              <QuizPlayScreen // Existing QuizPlayScreen is for personal quizzes
                config={currentPersonalQuizConfig} 
                onQuizComplete={handlePersonalQuizComplete} 
              />
            } 
          />
          <Route 
            path="/quiz/personal/results" 
            element={
              lastPersonalQuizAttempt ? (
                <QuizResultsScreen 
                  attempt={lastPersonalQuizAttempt} 
                  onPlayAgain={(config) => {
                    setCurrentPersonalQuizConfig(config);
                    navigate('/quiz/personal/play');
                  }}
                />
              ) : (
                <Navigate to="/" replace /> 
              )
            } 
          />

          {/* Group Quiz Creator Routes */}
          <Route 
            path="/quiz/group/create" 
            element={<CreateGroupQuizScreen onQuizCreated={handleGroupQuizCreated} />} 
          />
          <Route 
            path="/my-created-quizzes" 
            element={<MyCreatedQuizzesScreen />} 
          />
           <Route 
            path="/quiz/group/edit/:quizId" 
            element={<CreateGroupQuizScreen onQuizCreated={handleGroupQuizCreated} />} // Same component for edit
          />


          {/* Group Quiz Participant Routes */}
          <Route 
            path="/invited-quizzes" 
            element={<InvitedQuizzesScreen />} 
          />
           <Route 
            path="/quiz/group/join/:quizId" // Route for direct link joining
            element={<GroupQuizPreJoinScreen onJoinQuiz={handleJoinGroupQuiz} />} 
          />
          <Route 
            path="/quiz/group/play/:quizId" 
            element={
              currentGroupQuiz ? (
                <GroupQuizPlayScreen
                  groupQuiz={currentGroupQuiz}
                  onQuizComplete={handleGroupQuizComplete}
                />
              ) : (
                 <Navigate to="/invited-quizzes" replace /> // Or a specific error/join page
              )
            }
          />
           <Route 
            path="/quiz/group/results/:attemptId" // Participant sees their own results
            element={ 
              lastGroupQuizAttempt ? ( // Simplified, ideally fetch attempt by ID
                <QuizResultsScreen 
                  attempt={lastGroupQuizAttempt} 
                  onPlayAgain={(config) => { // Play again might not apply directly for group quiz like this
                     navigate('/'); // Or to invited quizzes
                  }}
                />
              ) : (
                <Navigate to="/invited-quizzes" replace />
              )
            }
          />

        </Route>
        
        {/* Fallback for non-authenticated or unmatched routes */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <LocalizationProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LocalizationProvider>
    </HashRouter>
  );
};

export default App;

import React from 'react';
import { useLocalization } from '../../hooks/useLocalization';
import { Language, TranslationSet } from '../../types';
import { UI_STRINGS_KEYS } from '../../constants';

interface LanguageToggleProps {
  className?: string;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({ className }) => {
  const { language, setLanguage, translate } = useLocalization();

  const toggleLanguage = () => {
    setLanguage(language === Language.ENGLISH ? Language.MALAYALAM : Language.ENGLISH);
  };

  return (
    <button
      onClick={toggleLanguage}
      className={`px-3 py-1.5 border border-primary text-primary rounded-md hover:bg-sky-50 text-sm font-medium transition-colors ${className} ${language === Language.MALAYALAM ? 'font-malayalam' : ''}`}
      aria-label="Toggle language"
    >
      {language === Language.ENGLISH ? translate(UI_STRINGS_KEYS.malayalam) : translate(UI_STRINGS_KEYS.english)}
    </button>
  );
};

import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useLocalization } from '../../hooks/useLocalization';
import { UI_STRINGS_KEYS, APP_NAME } from '../../constants';
import { Input } from '../Shared/Input';
import { Button } from '../Shared/Button';
import { Icon } from '../Shared/Icon';

export const LoginScreen: React.FC = () => {
  const { login, isLoading: authLoading } = useAuth();
  const { translate } = useLocalization();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError("Email and password are required."); // Or use a translated string
      return;
    }
    try {
      const user = await login(email, password);
      if (user) {
        navigate(from, { replace: true }); // Navigate to original destination or dashboard
      } else {
        setError(translate(UI_STRINGS_KEYS.errorLoginFailed));
      }
    } catch (err) {
      setError(translate(UI_STRINGS_KEYS.errorLoginFailed));
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light-bg py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-card-bg p-8 sm:p-10 rounded-xl shadow-card">
        <div>
          <Icon name="bookOpen" className="mx-auto h-12 w-auto text-primary" />
          <h2 className="mt-6 text-center text-3xl font-extrabold text-text-heading">
            {translate(UI_STRINGS_KEYS.loginPrompt)}
          </h2>
          <p className="mt-2 text-center text-sm text-text-main">
            {translate(UI_STRINGS_KEYS.appName)}
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <Input
            id="email"
            label={translate(UI_STRINGS_KEYS.email)}
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={translate(UI_STRINGS_KEYS.emailPlaceholder)}
          />
          <Input
            id="password"
            label={translate(UI_STRINGS_KEYS.password)}
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={translate(UI_STRINGS_KEYS.passwordPlaceholder)}
          />

          {error && <p className="text-sm text-error text-center">{error}</p>}

          <div className="flex items-center justify-between">
            {/* <div className="text-sm">
              <Link to="/forgot-password" className="font-medium text-primary hover:text-primary-hover">
                {translate(UI_STRINGS_KEYS.forgotPassword)}
              </Link>
            </div> */}
          </div>

          <div>
            <Button type="submit" fullWidth isLoading={authLoading} disabled={authLoading}>
              {translate(UI_STRINGS_KEYS.login)}
            </Button>
          </div>
        </form>
        <p className="mt-4 text-center text-sm text-text-main">
          {translate(UI_STRINGS_KEYS.dontHaveAccount)}{' '}
          <Link to="/signup" className="font-medium text-primary hover:text-primary-hover">
            {translate(UI_STRINGS_KEYS.signup)}
          </Link>
        </p>
      </div>
    </div>
  );
};

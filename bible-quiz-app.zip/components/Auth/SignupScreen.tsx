
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useLocalization } from '../../hooks/useLocalization';
import { UI_STRINGS_KEYS, APP_NAME } from '../../constants';
import { Input } from '../Shared/Input';
import { Button } from '../Shared/Button';
import { Icon } from '../Shared/Icon';

export const SignupScreen: React.FC = () => {
  const { signup, isLoading: authLoading } = useAuth();
  const { translate } = useLocalization();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password || !displayName) {
      setError("All fields are required."); // Or use a translated string
      return;
    }
    if (password.length < 6) {
        setError(translate(UI_STRINGS_KEYS.errorPasswordTooShort));
        return;
    }
    try {
      const user = await signup(email, password, displayName);
      if (user) {
        alert(translate(UI_STRINGS_KEYS.signupSuccess));
        navigate('/login');
      } else {
        setError(translate(UI_STRINGS_KEYS.errorSignupFailed) + " Email might already be in use.");
      }
    } catch (err) {
      setError(translate(UI_STRINGS_KEYS.errorSignupFailed));
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light-bg py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-card-bg p-8 sm:p-10 rounded-xl shadow-card">
        <div>
          <Icon name="bookOpen" className="mx-auto h-12 w-auto text-primary" />
          <h2 className="mt-6 text-center text-3xl font-extrabold text-text-heading">
            {translate(UI_STRINGS_KEYS.signupPrompt)}
          </h2>
           <p className="mt-2 text-center text-sm text-text-main">
            {translate(UI_STRINGS_KEYS.joinUs)} {translate(UI_STRINGS_KEYS.appName)}
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <Input
            id="displayName"
            label={translate(UI_STRINGS_KEYS.displayName)}
            type="text"
            required
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder={translate(UI_STRINGS_KEYS.displayNamePlaceholder)}
          />
          <Input
            id="email"
            label={translate(UI_STRINGS_KEYS.email)}
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={translate(UI_STRINGS_KEYS.emailPlaceholder)}
          />
          <Input
            id="password"
            label={translate(UI_STRINGS_KEYS.password)}
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={translate(UI_STRINGS_KEYS.passwordPlaceholder)}
          />

          {error && <p className="text-sm text-error text-center">{error}</p>}

          <div>
            <Button type="submit" fullWidth isLoading={authLoading} disabled={authLoading}>
              {translate(UI_STRINGS_KEYS.signup)}
            </Button>
          </div>
        </form>
        <p className="mt-4 text-center text-sm text-text-main">
          {translate(UI_STRINGS_KEYS.alreadyHaveAccount)}{' '}
          <Link to="/login" className="font-medium text-primary hover:text-primary-hover">
            {translate(UI_STRINGS_KEYS.login)}
          </Link>
        </p>
      </div>
    </div>
  );
};

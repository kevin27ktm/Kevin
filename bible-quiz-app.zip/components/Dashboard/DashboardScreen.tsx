
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useLocalization } from '../../hooks/useLocalization';
import { Language, User } from '../../types';
import { UI_STRINGS_KEYS } from '../../constants';
import { DashboardCard } from './DashboardCard';
import { Button } from '../Shared/Button';
import { Icon } from '../Shared/Icon';
import { LanguageToggle } from '../Auth/LanguageToggle';

interface DashboardScreenProps {
  onStartDefaultQuiz: () => void; // This is for personal quiz
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onStartDefaultQuiz }) => {
  const { currentUser, logout, isLoading: authLoading } = useAuth();
  const { translate, language } = useLocalization();
  const navigate = useNavigate();
  
  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const welcomeText = currentUser 
    ? translate(UI_STRINGS_KEYS.welcomeMessage, { name: currentUser.displayName || currentUser.email.split('@')[0] })
    : translate('welcomeMessageGeneric'); // Fallback if needed, though protected route should ensure user

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-10 flex flex-col sm:flex-row justify-between items-center sm:space-y-0 space-y-4">
          <div>
            <h1 className="text-3xl font-bold text-text-heading">
              {translate(UI_STRINGS_KEYS.appName)}
            </h1>
            <p className="text-text-main mt-1">
              {welcomeText}
            </p>
          </div>
          <div className="flex items-center space-x-3">
              <LanguageToggle />
              {currentUser && (
                <>
                  <Button onClick={() => navigate('/profile')} variant="ghost" size="sm" className="!px-2">
                    <Icon name="user" className="w-5 h-5" />
                  </Button>
                  <Button onClick={handleLogout} variant="outline" size="sm" isLoading={authLoading} disabled={authLoading}>
                    {translate(UI_STRINGS_KEYS.logout)}
                  </Button>
                </>
              )}
          </div>
        </header>

        <main>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.startPersonalQuiz)}
              description={translate(UI_STRINGS_KEYS.startPersonalQuizDescription)}
              iconName="lightBulb" 
              onClick={() => navigate('/quiz/personal/customize')} // Updated route for clarity
              isPrimaryAction={true}
              className="lg:col-span-1"
            />
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.createNewGroupQuiz)}
              description={translate(UI_STRINGS_KEYS.createNewGroupQuizDescription)}
              iconName="plusCircle" 
              onClick={() => navigate('/quiz/group/create')}
              className="lg:col-span-1"
            />
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.myCreatedQuizzes)}
              description={translate(UI_STRINGS_KEYS.myCreatedQuizzesDescription)}
              iconName="listBullet" 
              onClick={() => navigate('/my-created-quizzes')}
              className="lg:col-span-1"
            />
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.quizzesImInvitedTo)}
              description={translate(UI_STRINGS_KEYS.quizzesImInvitedToDescription)}
              iconName="inboxArrowDown" 
              onClick={() => navigate('/invited-quizzes')}
              className="lg:col-span-1"
            />
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.myProgress)}
              description={translate(UI_STRINGS_KEYS.myProgressDescription)}
              iconName="chartBar" 
              onClick={() => navigate('/profile')}
              className="lg:col-span-1"
            />
            <DashboardCard
              title={translate(UI_STRINGS_KEYS.leaderboard)}
              description={translate(UI_STRINGS_KEYS.leaderboardDescription)}
              iconName="academicCap" 
              onClick={() => alert(translate(UI_STRINGS_KEYS.leaderboardComingSoon))} 
              className="lg:col-span-1"
            />
          </div>
        </main>
        <footer className="mt-16 text-center text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} {translate(UI_STRINGS_KEYS.appName)}. {translate(UI_STRINGS_KEYS.allRightsReserved)}</p>
        </footer>
      </div>
    </div>
  );
};

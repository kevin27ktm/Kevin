import React from 'react';
import { Icon, IconName } from '../Shared/Icon';

interface DashboardCardProps {
  title: string;
  description?: string;
  iconName: IconName;
  onClick: () => void;
  className?: string;
  isPrimaryAction?: boolean; // To style the main "Start New Quiz" card differently
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ title, description, iconName, onClick, className, isPrimaryAction = false }) => {
  const cardBaseStyle = "p-6 rounded-xl shadow-card hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50";
  
  const cardStyle = isPrimaryAction 
    ? `bg-primary text-white hover:bg-primary-hover ${cardBaseStyle}`
    : `bg-card-bg ${cardBaseStyle}`;

  const iconColor = isPrimaryAction ? "text-white" : "text-primary";
  const iconBg = isPrimaryAction ? "bg-white/20" : "bg-sky-100"; // Light sky for normal cards
  const titleColor = isPrimaryAction ? "text-white" : "text-text-heading";
  const descriptionColor = isPrimaryAction ? "text-sky-100" : "text-text-main";


  return (
    <button
      onClick={onClick}
      className={`${cardStyle} ${className}`}
    >
      <div className="flex flex-col items-center text-center">
        <div className={`p-3 ${iconBg} rounded-full mb-4`}>
          <Icon name={iconName} className={`w-8 h-8 ${iconColor}`} />
        </div>
        <h3 className={`text-xl font-semibold ${titleColor} mb-1`}>{title}</h3>
        {description && <p className={`text-sm ${descriptionColor}`}>{description}</p>}
      </div>
    </button>
  );
};
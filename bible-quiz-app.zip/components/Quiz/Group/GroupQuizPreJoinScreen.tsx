
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLocalization } from '../../../hooks/useLocalization';
import { GroupQuiz, Language } from '../../../types';
import { UI_STRINGS_KEYS, LOCAL_STORAGE_KEYS } from '../../../constants';
import { Button } from '../../Shared/Button';
import { Icon } from '../../Shared/Icon';
import { LoadingSpinner } from '../../Shared/LoadingSpinner';

interface GroupQuizPreJoinScreenProps {
  onJoinQuiz: (quiz: GroupQuiz) => void;
}

const getQuizById = (quizId: string): GroupQuiz | null => {
  try {
    const storedQuizzes = localStorage.getItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES);
    if (!storedQuizzes) return null;
    const quizzes: GroupQuiz[] = JSON.parse(storedQuizzes);
    return quizzes.find(q => q.id === quizId) || null;
  } catch (e) {
    return null;
  }
};

export const GroupQuizPreJoinScreen: React.FC<GroupQuizPreJoinScreenProps> = ({ onJoinQuiz }) => {
  const { quizId } = useParams<{ quizId: string }>();
  const { translate, language } = useLocalization();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState<GroupQuiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [timeLeftToStart, setTimeLeftToStart] = useState<number | null>(null);

  useEffect(() => {
    if (!quizId) {
      setError(translate(UI_STRINGS_KEYS.invalidQuizId));
      setLoading(false);
      return;
    }
    const fetchedQuiz = getQuizById(quizId);
    if (fetchedQuiz) {
      setQuiz(fetchedQuiz);
    } else {
      setError(translate(UI_STRINGS_KEYS.quizNotFound));
    }
    setLoading(false);
  }, [quizId, translate]);

  useEffect(() => {
    if (!quiz) return;

    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const startTime = new Date(quiz.startTime).getTime();
      const diff = startTime - now;
      setTimeLeftToStart(diff > 0 ? diff : 0);
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, [quiz]);

  const canJoin = useMemo(() => {
    if (!quiz || !timeLeftToStart === null) return false;
    const now = new Date();
    const startTime = new Date(quiz.startTime);
    const endTime = new Date(quiz.endTime);
    // Allow joining if quiz is active or starts within next 10 minutes
    return (now >= startTime && now <= endTime) || (timeLeftToStart !== null && timeLeftToStart <= 10 * 60 * 1000 && now <= endTime) ;
  }, [quiz, timeLeftToStart]);

  const formatTime = (ms: number | null): string => {
    if (ms === null || ms < 0) return "00:00:00";
    let seconds = Math.floor(ms / 1000);
    let minutes = Math.floor(seconds / 60);
    let hours = Math.floor(minutes / 60);
    seconds %= 60;
    minutes %= 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const handleJoin = () => {
    if (quiz && canJoin) {
      onJoinQuiz(quiz);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner size="lg" /></div>;
  }
  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
         <Icon name="xCircle" className="w-16 h-16 text-error mx-auto mb-4" />
        <p className="text-xl text-text-heading mb-4">{error}</p>
        <Button onClick={() => navigate('/invited-quizzes')}>{translate(UI_STRINGS_KEYS.back)}</Button>
      </div>
    );
  }
  if (!quiz) {
     return <div className="min-h-screen flex items-center justify-center"><p>{translate(UI_STRINGS_KEYS.quizNotFound)}</p></div>;
  }

  const currentFontClass = language === Language.MALAYALAM || quiz.quizLanguage === Language.MALAYALAM ? 'font-malayalam' : '';
  const now = new Date();
  const quizHasEnded = now > new Date(quiz.endTime);
  const quizIsActive = now >= new Date(quiz.startTime) && now <= new Date(quiz.endTime);


  return (
    <div className={`min-h-screen flex flex-col items-center justify-center bg-light-bg p-4 ${currentFontClass}`}>
      <div className="w-full max-w-lg bg-card-bg p-6 md:p-8 rounded-xl shadow-card text-center">
        <Icon name="bookOpen" className="w-16 h-16 text-primary mx-auto mb-4" />
        <h1 className="text-2xl md:text-3xl font-bold text-text-heading mb-2">{quiz.title}</h1>
        {quiz.description && <p className="text-text-main mb-4">{quiz.description}</p>}

        <div className="grid grid-cols-2 gap-4 text-sm text-text-main mb-6 bg-slate-50 p-4 rounded-lg">
          <div><span className="font-semibold">{translate(UI_STRINGS_KEYS.creator)}:</span> Placeholder User</div>
          <div><span className="font-semibold">{translate(UI_STRINGS_KEYS.quizLanguage)}:</span> {translate(quiz.quizLanguage === Language.ENGLISH ? UI_STRINGS_KEYS.english : UI_STRINGS_KEYS.malayalam)}</div>
          <div><span className="font-semibold">{translate(UI_STRINGS_KEYS.numberOfQuestions)}:</span> {quiz.config.numberOfQuestions}</div>
          <div><span className="font-semibold">{translate(UI_STRINGS_KEYS.difficultyLevel)}:</span> {translate(quiz.difficulty)}</div>
          <div className="col-span-2"><span className="font-semibold">{translate(UI_STRINGS_KEYS.overallQuizDuration)}:</span> {Math.floor(quiz.totalDurationSeconds / 60)}{translate(UI_STRINGS_KEYS.timeUnitMinutes)} {quiz.totalDurationSeconds % 60}{translate(UI_STRINGS_KEYS.timeUnitSeconds)}</div>
          <div className="col-span-2"><span className="font-semibold">{translate(UI_STRINGS_KEYS.quizStartTime)}:</span> {new Date(quiz.startTime).toLocaleString()}</div>
        </div>

        {quizHasEnded ? (
            <p className="text-xl text-error font-semibold mb-6">{translate(UI_STRINGS_KEYS.quizHasEnded)}</p>
        ) : quizIsActive || (timeLeftToStart !== null && timeLeftToStart <= 0) ? (
            <p className="text-xl text-success font-semibold mb-6">{translate(UI_STRINGS_KEYS.quizIsLive)}</p>
        ) : timeLeftToStart !== null && timeLeftToStart > 0 ? (
          <div className="mb-6">
            <p className="text-lg text-primary font-semibold">{translate(UI_STRINGS_KEYS.quizStartsSoon)}</p>
            <p className="text-3xl font-bold text-text-heading">{formatTime(timeLeftToStart)}</p>
          </div>
        ) : null}
        
        <div className="space-y-3">
            <Button onClick={handleJoin} size="lg" fullWidth disabled={!canJoin || quizHasEnded}>
                {translate(UI_STRINGS_KEYS.joinQuiz)}
            </Button>
            <Button onClick={() => navigate('/invited-quizzes')} variant="outline" fullWidth>
                {translate(UI_STRINGS_KEYS.back)}
            </Button>
        </div>
      </div>
    </div>
  );
};

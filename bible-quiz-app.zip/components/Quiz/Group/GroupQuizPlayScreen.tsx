
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLocalization } from '../../../hooks/useLocalization';
import { useAuth } from '../../../hooks/useAuth';
import { Language, Question, QuizConfig, QuizAttempt, AnswerOption, GroupQuiz, QuizType } from '../../../types';
import { UI_STRINGS_KEYS, PER_QUESTION_TIMER_SECONDS, LOCAL_STORAGE_KEYS } from '../../../constants';
import { quizService } from '../../../services/quizService';
import { Button } from '../../Shared/Button';
import { LoadingSpinner } from '../../Shared/LoadingSpinner';
import { Timer } from '../Timer'; // Re-used for per-question timer
import { Icon } from '../../Shared/Icon';

interface GroupQuizPlayScreenProps {
  groupQuiz: GroupQuiz;
  onQuizComplete: (attempt: QuizAttempt) => void;
}

export const GroupQuizPlayScreen: React.FC<GroupQuizPlayScreenProps> = ({ groupQuiz, onQuizComplete }) => {
  const { translate, language: uiLanguage } = useLocalization();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswerId, setSelectedAnswerId] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({}); // questionId: selectedAnswerId or "timeout"
  const [isLoading, setIsLoading] = useState(true);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  
  const [quizStartTime] = useState<number>(Date.now()); // Participant's attempt start time
  const [overallTimeLeft, setOverallTimeLeft] = useState<number>(groupQuiz.totalDurationSeconds);
  const [perQuestionTimeLeft, setPerQuestionTimeLeft] = useState(PER_QUESTION_TIMER_SECONDS);

  const quizConfigForGeneration = useMemo((): QuizConfig => ({
    ...groupQuiz.config, // books, chapters, numberOfQuestions from groupQuiz
    quizLanguage: groupQuiz.quizLanguage,
    difficulty: groupQuiz.difficulty,
    quizType: QuizType.GROUP,
  }), [groupQuiz]);


  const finalizeQuiz = useCallback(() => {
    const timeTaken = Math.floor((Date.now() - quizStartTime) / 1000);
    const correctAnswersCount = Object.values(answers).reduce((count, ansId, idx) => {
        const question = questions[idx]; // Find question based on original index
        if (question && question.options) {
            return question.options.find(opt => opt.id === ansId)?.isCorrect ? count + 1 : count;
        }
        return count;
    }, 0);

    const accuracy = questions.length > 0 ? (correctAnswersCount / questions.length) * 100 : 0;
    
    const attempt: QuizAttempt = {
      id: `attempt_${groupQuiz.id}_${currentUser?.id || 'guest'}_${Date.now()}`,
      userId: currentUser?.id,
      quizType: QuizType.GROUP,
      groupQuizId: groupQuiz.id,
      config: quizConfigForGeneration,
      questions,
      answers,
      score,
      timeTaken,
      accuracy: parseFloat(accuracy.toFixed(1)),
      completedAt: new Date().toISOString(),
    };
    onQuizComplete(attempt);
  }, [quizStartTime, answers, questions, score, groupQuiz, currentUser, onQuizComplete, quizConfigForGeneration]);


  // Overall Timer Logic
  useEffect(() => {
    if (overallTimeLeft <= 0) {
      finalizeQuiz();
      return;
    }
    const timerId = setInterval(() => {
      setOverallTimeLeft(prevTime => prevTime - 1);
    }, 1000);
    return () => clearInterval(timerId);
  }, [overallTimeLeft, finalizeQuiz]);


  const loadQuestions = useCallback(async () => {
    setIsLoading(true);
    setApiError(null);
    try {
      // Check if user has already attempted this quiz (basic check)
      const attemptsStr = localStorage.getItem(LOCAL_STORAGE_KEYS.QUIZ_ATTEMPTS);
      if (attemptsStr && currentUser) {
        const allAttempts: QuizAttempt[] = JSON.parse(attemptsStr);
        const existingAttempt = allAttempts.find(att => att.groupQuizId === groupQuiz.id && att.userId === currentUser.id);
        if (existingAttempt) {
            setApiError(translate(UI_STRINGS_KEYS.alreadyTakenThisQuiz)); // Or navigate to results
            setIsLoading(false);
            // Potentially call onQuizComplete with existingAttempt if that's desired behavior
            // onQuizComplete(existingAttempt); 
            // For now, just show error and let user go back.
            return;
        }
      }

      const fetchedQuestions = await quizService.generateQuizQuestions(quizConfigForGeneration);
      if (fetchedQuestions.length === 0) {
        setApiError(translate(UI_STRINGS_KEYS.noQuestionsAvailable));
      } else {
        setQuestions(fetchedQuestions);
        // Ensure overall timer doesn't exceed actual number of questions if API returns fewer
        setOverallTimeLeft(Math.min(groupQuiz.totalDurationSeconds, fetchedQuestions.length * PER_QUESTION_TIMER_SECONDS));
      }
    } catch (error: any) {
      console.error("Failed to load questions for group quiz:", error);
      setApiError(translate(error.message) || translate(UI_STRINGS_KEYS.errorOccurred)); 
    } finally {
      setIsLoading(false);
    }
  }, [quizConfigForGeneration, translate, groupQuiz.id, currentUser]);

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]);

  const handleAnswerSelection = (answerId: string) => {
    if (showFeedback) return; 

    setSelectedAnswerId(answerId);
    const currentQuestion = questions[currentQuestionIndex];
    const correctAnswer = currentQuestion.options.find(opt => opt.isCorrect);

    const correct = correctAnswer?.id === answerId;
    setIsCorrect(correct);
    setShowFeedback(true);

    let currentQuestionScore = 0;
    if (correct) {
      currentQuestionScore = currentQuestion.points || groupQuiz.pointsPerCorrect;
      setScore(prevScore => prevScore + currentQuestionScore);
    } else if (groupQuiz.negativeMarkingEnabled) {
      currentQuestionScore = -(groupQuiz.negativePointsPerIncorrect || 0);
      setScore(prevScore => prevScore + currentQuestionScore);
    }
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: answerId }));
  };

  const handleNextQuestion = useCallback(() => {
    setShowFeedback(false);
    setSelectedAnswerId(null);
    setIsCorrect(null);
    setPerQuestionTimeLeft(PER_QUESTION_TIMER_SECONDS); 

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      finalizeQuiz();
    }
  }, [currentQuestionIndex, questions.length, finalizeQuiz]);
  
  const handlePerQuestionTimeUp = useCallback(() => {
    if (!showFeedback) { 
        setIsCorrect(false); 
        setShowFeedback(true);
        if(questions && questions[currentQuestionIndex]) { 
          setAnswers(prev => ({ ...prev, [questions[currentQuestionIndex].id]: "timeout" }));
          if (groupQuiz.negativeMarkingEnabled) {
             setScore(prevScore => prevScore - (groupQuiz.negativePointsPerIncorrect || 0));
          }
        }
    }
    // Automatically move to next after a short delay or let user click next
    // For now, user clicks next
  }, [showFeedback, questions, currentQuestionIndex, groupQuiz]);


  if (isLoading) {
    return <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-light-bg"><LoadingSpinner text={translate(UI_STRINGS_KEYS.loading)} size="lg" /></div>;
  }
  if (apiError) {
     return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-light-bg">
        <div className="bg-card-bg p-8 rounded-xl shadow-card">
            <Icon name="xCircle" className="w-16 h-16 text-error mb-4 mx-auto" />
            <p className="text-xl text-text-heading mb-1">{translate(UI_STRINGS_KEYS.errorLoadingQuestion)}</p>
            <p className="text-sm text-text-main mb-4">{apiError}</p>
            <Button onClick={() => navigate('/invited-quizzes')}>{translate(UI_STRINGS_KEYS.back)}</Button>
        </div>
      </div>
    );
  }
  if (questions.length === 0 && !isLoading) { 
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-light-bg">
        <div className="bg-card-bg p-8 rounded-xl shadow-card">
            <Icon name="xCircle" className="w-16 h-16 text-slate-400 mb-4 mx-auto" />
            <p className="text-xl text-text-heading mb-4">{translate(UI_STRINGS_KEYS.noQuestionsAvailable)}</p>
            <Button onClick={() => navigate('/invited-quizzes')}>{translate(UI_STRINGS_KEYS.back)}</Button>
        </div>
      </div>
    );
  }
  if (!questions[currentQuestionIndex]) {
    // This case should ideally not be reached if questions array is valid and index is managed
     return <div className="min-h-screen flex items-center justify-center"><p>{translate(UI_STRINGS_KEYS.errorLoadingQuestion)}</p></div>;
  }

  const currentQuestion = questions[currentQuestionIndex];
  const quizLangFontClass = groupQuiz.quizLanguage === Language.MALAYALAM ? 'font-malayalam' : '';
  
  const formatOverallTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center bg-light-bg p-4 ${quizLangFontClass}`}>
      <div className="w-full max-w-2xl bg-card-bg p-6 md:p-8 rounded-xl shadow-card">
        {/* Header Bar */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-border-color">
          <div>
            <span className="text-xs text-text-main">{translate(UI_STRINGS_KEYS.overallQuizTimer)}</span>
            <p className={`text-lg font-semibold ${overallTimeLeft <= 30 ? 'text-error' : 'text-text-heading'}`}>{formatOverallTime(overallTimeLeft)}</p>
          </div>
          <div className="text-center">
             <span className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.question)} {currentQuestionIndex + 1}/{questions.length}</span>
             <p className="text-lg font-semibold text-primary">{translate(UI_STRINGS_KEYS.points)}: {score}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-text-main">{translate(UI_STRINGS_KEYS.perQuestionTimer)}</p>
            <Timer 
                key={`q-${currentQuestionIndex}`} // Important: Re-mount timer for each question
                initialTime={PER_QUESTION_TIMER_SECONDS} 
                onTimeUp={handlePerQuestionTimeUp} 
                isPaused={showFeedback}
            />
          </div>
        </div>

        <div className="mb-6 min-h-[6rem]">
          <h2 className="text-xl md:text-2xl font-semibold text-text-heading mb-2">{currentQuestion.text}</h2>
          {currentQuestion.reference && <p className="text-xs text-slate-500 italic">({currentQuestion.reference})</p>}
        </div>

        <div className="space-y-3 mb-6">
          {(currentQuestion.options || []).map((option) => {
            let buttonClass = "w-full text-left p-3 border rounded-lg transition-all duration-200 ease-in-out font-medium ";
            if (showFeedback) {
              if (option.isCorrect) buttonClass += "bg-emerald-50 border-success text-emerald-700 ring-2 ring-success";
              else if (selectedAnswerId === option.id && !option.isCorrect) buttonClass += "bg-rose-50 border-error text-rose-700 ring-2 ring-error";
              else buttonClass += "bg-slate-100 border-border-color text-slate-500 opacity-70 cursor-not-allowed";
            } else if (selectedAnswerId === option.id) buttonClass += "bg-sky-50 border-primary text-primary ring-2 ring-primary";
            else buttonClass += "bg-slate-50 hover:bg-sky-50 border-border-color hover:border-primary text-text-main hover:text-primary";
            return (
              <button key={option.id} onClick={() => handleAnswerSelection(option.id)} disabled={showFeedback} className={buttonClass} aria-pressed={selectedAnswerId === option.id}>
                {option.text}
              </button>
            );
          })}
        </div>
        
        {showFeedback && (
          <div className="text-center mb-4 p-3 rounded-md min-h-[6rem]">
            {isCorrect === true && <div className="flex items-center justify-center text-success"><Icon name="checkCircle" className="w-6 h-6 mr-2"/><p className="text-lg font-semibold">{translate(UI_STRINGS_KEYS.correct)}</p></div>}
            {isCorrect === false && <div className="flex items-center justify-center text-error"><Icon name="xCircle" className="w-6 h-6 mr-2"/><p className="text-lg font-semibold">{translate(UI_STRINGS_KEYS.incorrect)}</p></div>}
            <Button onClick={handleNextQuestion} fullWidth className="mt-4">
              {currentQuestionIndex < questions.length - 1 ? translate(UI_STRINGS_KEYS.nextQuestion) : translate(UI_STRINGS_KEYS.quizResults)}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

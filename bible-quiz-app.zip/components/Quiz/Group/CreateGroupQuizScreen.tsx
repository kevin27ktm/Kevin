
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLocalization } from '../../../hooks/useLocalization';
import { useAuth } from '../../../hooks/useAuth';
import { Language, BibleBook, BibleChapter, QuizConfig, GroupQuiz, QuizDifficulty, QuizType } from '../../../types';
import { UI_STRINGS_KEYS, DEFAULT_QUIZ_SETTINGS, PER_QUESTION_TIMER_SECONDS, LOCAL_STORAGE_KEYS } from '../../../constants';
import { BIBLE_BOOKS_DATA } from '../../../utils/bibleData';
import { Button } from '../../Shared/Button';
import { Input } from '../../Shared/Input';
import { Icon } from '../../Shared/Icon';

interface CreateGroupQuizScreenProps {
  onQuizCreated: (quiz: GroupQuiz) => void;
}

const getStoredGroupQuizzes = (): GroupQuiz[] => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("Error fetching group quizzes from localStorage", e);
    return [];
  }
};

const storeGroupQuizzes = (quizzes: GroupQuiz[]) => {
  localStorage.setItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES, JSON.stringify(quizzes));
};


export const CreateGroupQuizScreen: React.FC<CreateGroupQuizScreenProps> = ({ onQuizCreated }) => {
  const { translate, language: uiLanguage } = useLocalization();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { quizId: editingQuizId } = useParams<{ quizId?: string }>(); // For editing existing quiz

  const [step, setStep] = useState(1);

  // Step 1: Details
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [quizContentLanguage, setQuizContentLanguage] = useState<Language>(DEFAULT_QUIZ_SETTINGS.language);

  // Step 2: Content
  const [selectedBookIds, setSelectedBookIds] = useState<string[]>([]);
  const [selectedChapters, setSelectedChapters] = useState<Record<string, number[]>>({});
  const [numberOfQuestions, setNumberOfQuestions] = useState<number>(DEFAULT_QUIZ_SETTINGS.numberOfQuestions);
  const [difficulty, setDifficulty] = useState<QuizDifficulty>(DEFAULT_QUIZ_SETTINGS.difficulty);
  const [expandedBook, setExpandedBook] = useState<string | null>(null);

  // Step 3: Settings
  const [startTime, setStartTime] = useState<string>(new Date(Date.now() + 60 * 60 * 1000).toISOString().substring(0, 16)); // Default 1 hour from now
  const [endTime, setEndTime] = useState<string>(new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString().substring(0, 16)); // Default 2 hours from now
  const [pointsPerCorrect, setPointsPerCorrect] = useState<number>(DEFAULT_QUIZ_SETTINGS.pointsPerCorrect);
  const [negativeMarkingEnabled, setNegativeMarkingEnabled] = useState<boolean>(DEFAULT_QUIZ_SETTINGS.negativeMarkingEnabled);
  const [negativePoints, setNegativePoints] = useState<number>(DEFAULT_QUIZ_SETTINGS.negativePointsPerIncorrect);
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    // Set quiz content language based on UI language initially
    setQuizContentLanguage(uiLanguage);
  }, [uiLanguage]);

  useEffect(() => {
    if (editingQuizId) {
      const quizzes = getStoredGroupQuizzes();
      const quizToEdit = quizzes.find(q => q.id === editingQuizId);
      if (quizToEdit && quizToEdit.creatorId === currentUser?.id) { // Ensure creator is editing
        setTitle(quizToEdit.title);
        setDescription(quizToEdit.description || '');
        setQuizContentLanguage(quizToEdit.quizLanguage);
        setSelectedBookIds(quizToEdit.config.books);
        setSelectedChapters(quizToEdit.config.chapters);
        setNumberOfQuestions(quizToEdit.config.numberOfQuestions);
        setDifficulty(quizToEdit.difficulty);
        setStartTime(new Date(quizToEdit.startTime).toISOString().substring(0, 16));
        setEndTime(new Date(quizToEdit.endTime).toISOString().substring(0, 16));
        setPointsPerCorrect(quizToEdit.pointsPerCorrect);
        setNegativeMarkingEnabled(quizToEdit.negativeMarkingEnabled);
        setNegativePoints(quizToEdit.negativePointsPerIncorrect || 0);
      } else {
        alert("Quiz not found or you don't have permission to edit.");
        navigate('/my-created-quizzes');
      }
    }
  }, [editingQuizId, currentUser, navigate]);


  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    if (!title.trim()) newErrors.title = translate(UI_STRINGS_KEYS.quizTitleRequired);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    if (selectedBookIds.length === 0) newErrors.books = translate(UI_STRINGS_KEYS.pleaseSelectBooks);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    const newErrors: Record<string, string> = {};
    if (new Date(startTime) <= new Date()) newErrors.startTime = translate(UI_STRINGS_KEYS.quizStartAfterNow);
    if (new Date(endTime) <= new Date(startTime)) newErrors.endTime = translate(UI_STRINGS_KEYS.quizEndAfterStart);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    let isValid = false;
    if (step === 1) isValid = validateStep1();
    else if (step === 2) isValid = validateStep2();
    else if (step === 3) isValid = validateStep3(); // Validate before final submit
    
    if (isValid && step < 3) {
      setStep(s => s + 1);
    } else if (isValid && step === 3) {
        handleSubmit();
    }
  };

  const handlePrevStep = () => {
    if (step > 1) setStep(s => s - 1);
  };
  
  const handleSubmit = () => {
    if (!currentUser) {
        alert("User not authenticated."); // Should not happen if route is protected
        return;
    }
    if (!validateStep1() || !validateStep2() || !validateStep3()) {
        alert("Please correct the errors before submitting.");
        return;
    }

    const quizConfig: QuizConfig = {
      books: selectedBookIds,
      chapters: selectedChapters,
      numberOfQuestions,
      quizLanguage: quizContentLanguage,
      difficulty,
      quizType: QuizType.GROUP,
    };

    const newGroupQuiz: GroupQuiz = {
      id: editingQuizId || `groupquiz_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      title,
      description,
      creatorId: currentUser.id,
      quizLanguage: quizContentLanguage,
      config: quizConfig,
      difficulty,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      totalDurationSeconds: numberOfQuestions * PER_QUESTION_TIMER_SECONDS,
      pointsPerCorrect,
      negativeMarkingEnabled,
      negativePointsPerIncorrect: negativeMarkingEnabled ? negativePoints : 0,
      status: 'scheduled', // default
      createdAt: editingQuizId ? (getStoredGroupQuizzes().find(q=>q.id === editingQuizId)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      participants: editingQuizId ? (getStoredGroupQuizzes().find(q=>q.id === editingQuizId)?.participants || []) : [],
    };

    const quizzes = getStoredGroupQuizzes();
    if (editingQuizId) {
        const index = quizzes.findIndex(q => q.id === editingQuizId);
        if (index !== -1) quizzes[index] = newGroupQuiz;
        else quizzes.push(newGroupQuiz); // Should not happen if edit logic is correct
    } else {
        quizzes.push(newGroupQuiz);
    }
    storeGroupQuizzes(quizzes);
    onQuizCreated(newGroupQuiz);
  };


  // Book and Chapter selection logic (similar to PersonalQuizCustomizationScreen)
  const handleBookSelection = (bookId: string) => {
    setSelectedBookIds(prev => prev.includes(bookId) ? prev.filter(id => id !== bookId) : [...prev, bookId]);
    if (selectedBookIds.includes(bookId)) {
      setSelectedChapters(prev => { const newState = {...prev}; delete newState[bookId]; return newState; });
    }
  };
  const handleChapterSelection = (bookId: string, chapterNumber: number) => {
    setSelectedChapters(prev => {
      const current = prev[bookId] || [];
      return { ...prev, [bookId]: current.includes(chapterNumber) ? current.filter(cn => cn !== chapterNumber) : [...current, chapterNumber] };
    });
  };
  const handleSelectAllChapters = (bookId: string) => {
    const book = BIBLE_BOOKS_DATA.find(b => b.id === bookId);
    if (!book) return;
    setSelectedChapters(prev => ({ ...prev, [bookId]: book.chapters.map(c => c.chapterNumber) }));
  };
   const handleSelectAllBooks = (testament?: 'OT' | 'NT') => {
    setSelectedBookIds(BIBLE_BOOKS_DATA.filter(b => !testament || b.testament === testament).map(b => b.id));
  };
  const currentFontClass = uiLanguage === Language.MALAYALAM ? 'font-malayalam' : '';

  const renderStepContent = () => {
    switch (step) {
      case 1: // Details
        return (
          <div className="space-y-6">
            <Input id="title" label={translate(UI_STRINGS_KEYS.quizTitle)} value={title} onChange={e => setTitle(e.target.value)} placeholder={translate(UI_STRINGS_KEYS.quizTitlePlaceholder)} error={errors.title} required />
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-text-main mb-1">{translate(UI_STRINGS_KEYS.quizDescription)}</label>
              <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder={translate(UI_STRINGS_KEYS.quizDescriptionPlaceholder)} rows={3} className="block w-full px-3 py-2 border border-border-color rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
            </div>
            <div>
              <h3 className="text-md font-medium text-text-main mb-2">{translate(UI_STRINGS_KEYS.quizLanguage)}</h3>
              <div className="flex space-x-4">
                {(Object.values(Language) as Language[]).map(lang => (
                  <label key={lang} className="flex items-center space-x-2 cursor-pointer">
                    <input type="radio" name="quizContentLanguage" className="form-radio h-5 w-5 text-primary" checked={quizContentLanguage === lang} onChange={() => setQuizContentLanguage(lang)} />
                    <span className={`text-text-main ${lang === Language.MALAYALAM ? 'font-malayalam' : ''}`}>{translate(lang === Language.ENGLISH ? UI_STRINGS_KEYS.english : UI_STRINGS_KEYS.malayalam)}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );
      case 2: // Content
        return (
          <div className="space-y-6">
            {errors.books && <p className="text-sm text-error">{errors.books}</p>}
            <section> {/* Book Selection */}
              <h3 className="text-md font-medium text-text-main mb-2">{translate(UI_STRINGS_KEYS.chooseBibleBooks)}</h3>
               <div className="mb-4 space-x-2">
                <Button size="sm" variant="outline" onClick={() => handleSelectAllBooks('OT')}>{translate(UI_STRINGS_KEYS.oldTestament)} ({translate(UI_STRINGS_KEYS.selectAll)})</Button>
                <Button size="sm" variant="outline" onClick={() => handleSelectAllBooks('NT')}>{translate(UI_STRINGS_KEYS.newTestament)} ({translate(UI_STRINGS_KEYS.selectAll)})</Button>
                <Button size="sm" variant="outline" onClick={() => setSelectedBookIds([])}>{translate(UI_STRINGS_KEYS.deselectAllBooks)}</Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
                {['OT', 'NT'].map(testament => (
                  <div key={testament}>
                    <h4 className="text-sm font-semibold text-text-heading mb-1">{translate(testament === 'OT' ? UI_STRINGS_KEYS.oldTestament : UI_STRINGS_KEYS.newTestament)}</h4>
                    {BIBLE_BOOKS_DATA.filter(b => b.testament === testament).map(book => (
                      <div key={book.id} className="mb-1 p-2 bg-slate-50 border border-slate-200 rounded">
                        <div className="flex items-center justify-between">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="form-checkbox h-4 w-4 text-primary" checked={selectedBookIds.includes(book.id)} onChange={() => handleBookSelection(book.id)} />
                            <span className="text-sm">{uiLanguage === Language.MALAYALAM ? book.nameMl : book.name}</span>
                          </label>
                          {selectedBookIds.includes(book.id) && (<Button size="sm" variant="ghost" onClick={() => setExpandedBook(expandedBook === book.id ? null : book.id)} className="!text-xs !py-0.5 !px-1">{translate(UI_STRINGS_KEYS.chooseChapters)} {expandedBook === book.id ? '▲' : '▼'}</Button>)}
                        </div>
                        {selectedBookIds.includes(book.id) && expandedBook === book.id && (
                          <div className="mt-2 pt-2 pl-3 border-l-2 border-primary/20">
                            <Button size="sm" variant="outline" onClick={() => handleSelectAllChapters(book.id)} className="mr-1 !text-xs !py-0.5 !px-1">{translate(UI_STRINGS_KEYS.allChapters)}</Button>
                            <Button size="sm" variant="outline" onClick={() => setSelectedChapters(p => ({...p, [book.id]:[]}))} className="!text-xs !py-0.5 !px-1">{translate(UI_STRINGS_KEYS.deselectAll)}</Button>
                            <div className="grid grid-cols-5 gap-1 mt-1 max-h-40 overflow-y-auto pr-1 text-xs">
                              {book.chapters.map(ch => <label key={ch.id} className="flex items-center space-x-1 p-0.5 border rounded cursor-pointer hover:bg-sky-50"><input type="checkbox" className="form-checkbox h-3 w-3" checked={(selectedChapters[book.id] || []).includes(ch.chapterNumber)} onChange={() => handleChapterSelection(book.id, ch.chapterNumber)} /><span>{ch.chapterNumber}</span></label>)}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </section>
            <div> {/* Number of Questions */}
              <label htmlFor="numQuestions" className="block text-md font-medium text-text-main mb-1">{translate(UI_STRINGS_KEYS.numberOfQuestions)}: <span className="text-primary">{numberOfQuestions}</span></label>
              <input id="numQuestions" type="range" min="5" max="50" step="5" value={numberOfQuestions} onChange={e => setNumberOfQuestions(parseInt(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary" />
            </div>
            <div> {/* Difficulty Level */}
              <h3 className="text-md font-medium text-text-main mb-2">{translate(UI_STRINGS_KEYS.difficultyLevel)}</h3>
              <div className="flex flex-wrap gap-2">
                {(Object.values(QuizDifficulty) as QuizDifficulty[]).map(level => (
                  <label key={level} className="flex items-center space-x-2 cursor-pointer p-2 border border-border-color rounded-md hover:border-primary has-[:checked]:bg-sky-50 has-[:checked]:border-primary">
                    <input type="radio" name="difficulty" className="form-radio h-4 w-4 text-primary" checked={difficulty === level} onChange={() => setDifficulty(level)} />
                    <span className="text-sm">{translate(level)}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );
      case 3: // Settings
        return (
          <div className="space-y-6">
            <Input id="startTime" label={translate(UI_STRINGS_KEYS.quizStartTime)} type="datetime-local" value={startTime} onChange={e => setStartTime(e.target.value)} error={errors.startTime} required />
            <Input id="endTime" label={translate(UI_STRINGS_KEYS.quizEndTime)} type="datetime-local" value={endTime} onChange={e => setEndTime(e.target.value)} error={errors.endTime} required />
            <Input id="pointsPerCorrect" label={translate(UI_STRINGS_KEYS.pointsPerCorrectAnswer)} type="number" min="1" value={pointsPerCorrect} onChange={e => setPointsPerCorrect(parseInt(e.target.value))} required />
            <div>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input type="checkbox" className="form-checkbox h-5 w-5 text-primary" checked={negativeMarkingEnabled} onChange={e => setNegativeMarkingEnabled(e.target.checked)} />
                <span>{translate(UI_STRINGS_KEYS.negativeMarking)}</span>
              </label>
              {negativeMarkingEnabled && (
                <Input id="negativePoints" label={translate(UI_STRINGS_KEYS.negativePointsPerIncorrect)} type="number" min="0" value={negativePoints} onChange={e => setNegativePoints(parseInt(e.target.value))} wrapperClassName="mt-2" />
              )}
            </div>
            <div>
                <p className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.overallQuizDuration)}: {Math.floor((numberOfQuestions * PER_QUESTION_TIMER_SECONDS) / 60)} {translate(UI_STRINGS_KEYS.timeUnitMinutes)} {(numberOfQuestions * PER_QUESTION_TIMER_SECONDS) % 60} {translate(UI_STRINGS_KEYS.timeUnitSeconds)}</p>
            </div>
          </div>
        );
      default: return null;
    }
  };

  const stepTitles = [
    translate(UI_STRINGS_KEYS.step1Details),
    translate(UI_STRINGS_KEYS.step2Content),
    translate(UI_STRINGS_KEYS.step3Settings)
  ];

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-6 flex justify-between items-center">
          <Button onClick={() => navigate('/my-created-quizzes')} variant="ghost" size="sm" className="flex items-center">
            <Icon name="arrowRight" className="w-5 h-5 mr-1 transform rotate-180" /> {translate(UI_STRINGS_KEYS.back)}
          </Button>
          <h1 className="text-2xl font-bold text-text-heading">{editingQuizId ? translate(UI_STRINGS_KEYS.editQuiz) : translate(UI_STRINGS_KEYS.createGroupQuizTitle)}</h1>
          <div></div>
        </header>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-1">
            {stepTitles.map((title, index) => (
              <span key={index} className={`text-xs font-medium ${index + 1 <= step ? 'text-primary' : 'text-slate-400'}`}>
                {title}
              </span>
            ))}
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div className="bg-primary h-2 rounded-full" style={{ width: `${(step / 3) * 100}%` }}></div>
          </div>
        </div>
        
        <div className="bg-card-bg p-6 sm:p-8 rounded-xl shadow-card">
          {renderStepContent()}
          <div className="mt-8 flex justify-between items-center">
            <Button onClick={handlePrevStep} variant="outline" disabled={step === 1}>
              {translate(UI_STRINGS_KEYS.back)}
            </Button>
            <Button onClick={handleNextStep}>
              {step < 3 ? translate(UI_STRINGS_KEYS.next) : (editingQuizId ? translate(UI_STRINGS_KEYS.save) : translate(UI_STRINGS_KEYS.createQuizButton))}
            </Button>
          </div>
        </div>
      </div>
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #e2e8f0; border-radius: 8px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #0284c7; border-radius: 8px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #0369a1; }
      `}} />
    </div>
  );
};

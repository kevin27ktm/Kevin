
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../../../hooks/useLocalization';
import { useAuth } from '../../../hooks/useAuth';
import { GroupQuiz, Language } from '../../../types';
import { UI_STRINGS_KEYS, LOCAL_STORAGE_KEYS } from '../../../constants';
import { Button } from '../../Shared/Button';
import { Icon } from '../../Shared/Icon';
import { Input } from '../../Shared/Input'; // Added for displaying the link

const getStoredGroupQuizzes = (): GroupQuiz[] => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};

const storeGroupQuizzes = (quizzes: GroupQuiz[]) => {
  localStorage.setItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES, JSON.stringify(quizzes));
};

export const MyCreatedQuizzesScreen: React.FC = () => {
  const { translate, language } = useLocalization();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [createdQuizzes, setCreatedQuizzes] = useState<GroupQuiz[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<GroupQuiz | null>(null);
  
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [shareableLink, setShareableLink] = useState<string>('');
  const [quizToShareTitle, setQuizToShareTitle] = useState<string>('');
  const [linkCopiedMessage, setLinkCopiedMessage] = useState<string>('');


  useEffect(() => {
    if (currentUser) {
      const allQuizzes = getStoredGroupQuizzes();
      setCreatedQuizzes(allQuizzes.filter(quiz => quiz.creatorId === currentUser.id).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ));
    }
  }, [currentUser]);

  const handleDeleteQuiz = (quizId: string) => {
    const updatedQuizzes = createdQuizzes.filter(quiz => quiz.id !== quizId);
    setCreatedQuizzes(updatedQuizzes);
    const allQuizzes = getStoredGroupQuizzes().filter(q => q.id !== quizId);
    storeGroupQuizzes(allQuizzes);
    setShowDeleteConfirm(null);
  };

  const openShareModal = (quiz: GroupQuiz) => {
    const shareUrl = `${window.location.origin}${window.location.pathname}#/quiz/group/join/${quiz.id}`;
    setShareableLink(shareUrl);
    setQuizToShareTitle(quiz.title);
    setShowShareModal(true);
    setLinkCopiedMessage(''); // Reset copied message
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareableLink)
      .then(() => {
        setLinkCopiedMessage(translate(UI_STRINGS_KEYS.quizLinkCopied));
        setTimeout(() => setLinkCopiedMessage(''), 2000); // Clear message after 2 seconds
      })
      .catch(err => {
        console.error('Failed to copy quiz link:', err);
        setLinkCopiedMessage('Failed to copy link.');
        setTimeout(() => setLinkCopiedMessage(''), 2000);
      });
  };
  
  const getQuizStatus = (quiz: GroupQuiz): { textKey: string, colorClass: string } => {
    const now = new Date();
    const startTime = new Date(quiz.startTime);
    const endTime = new Date(quiz.endTime);

    if (quiz.status === 'cancelled') return { textKey: UI_STRINGS_KEYS.statusCancelled, colorClass: 'text-slate-500 bg-slate-100' };
    if (now > endTime) return { textKey: UI_STRINGS_KEYS.statusCompleted, colorClass: 'text-emerald-700 bg-emerald-50' };
    if (now >= startTime && now <= endTime) return { textKey: UI_STRINGS_KEYS.statusActive, colorClass: 'text-blue-700 bg-blue-50' };
    return { textKey: UI_STRINGS_KEYS.statusScheduled, colorClass: 'text-amber-700 bg-amber-50' };
  };

  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-8 flex justify-between items-center">
           <Button onClick={() => navigate('/')} variant="ghost" size="sm" className="flex items-center">
            <Icon name="arrowRight" className="w-5 h-5 mr-1 transform rotate-180" /> {translate(UI_STRINGS_KEYS.backToDashboard)}
          </Button>
          <h1 className="text-2xl font-bold text-text-heading">{translate(UI_STRINGS_KEYS.myCreatedQuizzes)}</h1>
          <Button onClick={() => navigate('/quiz/group/create')} variant="primary">
            <Icon name="plusCircle" className="w-5 h-5 mr-2" />
            {translate(UI_STRINGS_KEYS.createNewGroupQuiz)}
          </Button>
        </header>

        {createdQuizzes.length === 0 ? (
          <div className="text-center py-10">
            <Icon name="listBullet" className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-text-main text-lg">{translate(UI_STRINGS_KEYS.noQuizzesCreatedYet)}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {createdQuizzes.map(quiz => {
              const statusInfo = getQuizStatus(quiz);
              const isEditable = new Date(quiz.startTime) > new Date() && quiz.status === 'scheduled';
              return (
              <div key={quiz.id} className="bg-card-bg p-4 rounded-lg shadow-subtle">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-2">
                  <h2 className="text-lg font-semibold text-text-heading">{quiz.title}</h2>
                  <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${statusInfo.colorClass}`}>{translate(statusInfo.textKey)}</span>
                </div>
                {quiz.description && <p className="text-sm text-text-main mb-2">{quiz.description}</p>}
                <div className="text-xs text-slate-500 mb-3 space-y-0.5">
                    <p>ID: {quiz.id}</p>
                    <p>{translate(UI_STRINGS_KEYS.quizStartTime)}: {new Date(quiz.startTime).toLocaleString()}</p>
                    <p>{translate(UI_STRINGS_KEYS.quizEndTime)}: {new Date(quiz.endTime).toLocaleString()}</p>
                    <p>{translate(UI_STRINGS_KEYS.numberOfQuestions)}: {quiz.config.numberOfQuestions}</p>
                    <p>{translate(UI_STRINGS_KEYS.participants)}: {quiz.participants?.length || 0} (Feature in progress)</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => openShareModal(quiz)}><Icon name="share" className="w-4 h-4 mr-1"/>{translate(UI_STRINGS_KEYS.shareLink)}</Button>
                  <Button size="sm" variant="ghost" onClick={() => alert(translate(UI_STRINGS_KEYS.comingSoon))}><Icon name="chartBar" className="w-4 h-4 mr-1"/>{translate(UI_STRINGS_KEYS.viewResults)}</Button>
                  {isEditable && (
                    <Button size="sm" variant="ghost" onClick={() => navigate(`/quiz/group/edit/${quiz.id}`)}><Icon name="pencil" className="w-4 h-4 mr-1"/>{translate(UI_STRINGS_KEYS.editQuiz)}</Button>
                  )}
                  {isEditable && (
                    <Button size="sm" variant="danger" onClick={() => setShowDeleteConfirm(quiz)}><Icon name="trash" className="w-4 h-4 mr-1"/>{translate(UI_STRINGS_KEYS.deleteQuiz)}</Button>
                  )}
                </div>
              </div>
            )})}
          </div>
        )}
      </div>

      {/* Share Link Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out">
          <div className="bg-card-bg p-6 rounded-xl shadow-xl max-w-lg w-full transform transition-all duration-300 ease-in-out scale-100">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-text-heading">
                    {translate(UI_STRINGS_KEYS.shareLink)}: <span className="text-primary">{quizToShareTitle}</span>
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setShowShareModal(false)} className="!p-1">
                    <Icon name="xCircle" className="w-6 h-6 text-slate-500 hover:text-error" />
                </Button>
            </div>
            <p className="text-sm text-text-main mb-2">
                {translate('shareQuizInstruction') || 'Copy and share this link with participants:'}
            </p>
            <div className="flex items-center space-x-2">
              <Input
                id="shareableLinkInput"
                type="text"
                value={shareableLink}
                readOnly
                className="bg-slate-100 text-sm"
                wrapperClassName="flex-grow mb-0"
                onClick={(e) => (e.target as HTMLInputElement).select()}
              />
              <Button onClick={handleCopyLink} variant="primary">
                {translate('copyLink') || 'Copy'}
              </Button>
            </div>
            {linkCopiedMessage && (
              <p className="text-sm text-success mt-2 text-center">{linkCopiedMessage}</p>
            )}
            <div className="mt-6 text-center">
                 <Button variant="outline" onClick={() => setShowShareModal(false)}>
                    {translate(UI_STRINGS_KEYS.close)}
                </Button>
            </div>
          </div>
        </div>
      )}


      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-card-bg p-6 rounded-lg shadow-xl max-w-sm w-full">
            <h3 className="text-lg font-semibold text-text-heading mb-2">{translate(UI_STRINGS_KEYS.confirmDeleteQuizTitle)}</h3>
            <p className="text-sm text-text-main mb-4">{translate(UI_STRINGS_KEYS.confirmDeleteQuizMessage, { title: showDeleteConfirm.title })}</p>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(null)}>{translate(UI_STRINGS_KEYS.cancel)}</Button>
              <Button variant="danger" onClick={() => handleDeleteQuiz(showDeleteConfirm.id)}>{translate(UI_STRINGS_KEYS.delete)}</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

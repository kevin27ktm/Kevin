
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../../../hooks/useLocalization';
import { useAuth } from '../../../hooks/useAuth';
import { GroupQuiz, Language, QuizParticipant, User } from '../../../types';
import { UI_STRINGS_KEYS, LOCAL_STORAGE_KEYS } from '../../../constants';
import { Button } from '../../Shared/Button';
import { Input } from '../../Shared/Input';
import { Icon } from '../../Shared/Icon';

// Helper to get all group quizzes (simulates fetching from a backend)
const getAllGroupQuizzes = (): GroupQuiz[] => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEYS.CREATED_GROUP_QUIZZES);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};

// Helper to get user's participation history
const getParticipantHistory = (userId: string): QuizParticipant[] => {
  try {
    const historyStr = localStorage.getItem(LOCAL_STORAGE_KEYS.JOINED_GROUP_QUIZZES_HISTORY);
    if (!historyStr) return [];
    const allHistory: QuizParticipant[] = JSON.parse(historyStr);
    return allHistory.filter(p => p.userId === userId);
  } catch(e) { return []; }
}

// Mock: Assume invited quizzes are just all available quizzes for now.
// In a real app, this would be based on actual invitations.
const getMockInvitedQuizzes = (allQuizzes: GroupQuiz[], currentUser: User | null): GroupQuiz[] => {
  if (!currentUser) return [];
  // For demo, show all quizzes not created by the current user and are scheduled or active
  // Or, if we had a proper invitation system, we'd filter by that.
  return allQuizzes.filter(quiz => {
    const now = new Date();
    const endTime = new Date(quiz.endTime);
    // quiz.creatorId !== currentUser.id && // Don't show own quizzes as "invitations"
    return now < endTime && quiz.status !== 'cancelled'; // Only show joinable quizzes
  }).sort((a,b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
};

export const InvitedQuizzesScreen: React.FC = () => {
  const { translate, language } = useLocalization();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [invitedQuizzes, setInvitedQuizzes] = useState<GroupQuiz[]>([]);
  const [quizIdToJoin, setQuizIdToJoin] = useState('');
  const [joinError, setJoinError] = useState('');
  const [userAttempts, setUserAttempts] = useState<Record<string, QuizParticipant>>({}); // quizId: attempt


  useEffect(() => {
    if (currentUser) {
      const allQuizzes = getAllGroupQuizzes();
      setInvitedQuizzes(getMockInvitedQuizzes(allQuizzes, currentUser));
      const history = getParticipantHistory(currentUser.id);
      const attemptsMap: Record<string, QuizParticipant> = {};
      history.forEach(att => attemptsMap[att.groupQuizId] = att);
      setUserAttempts(attemptsMap);
    }
  }, [currentUser]);

  const handleJoinWithId = () => {
    setJoinError('');
    if (!quizIdToJoin.trim()) {
      setJoinError(translate(UI_STRINGS_KEYS.invalidQuizId));
      return;
    }
    const allQuizzes = getAllGroupQuizzes();
    const quiz = allQuizzes.find(q => q.id === quizIdToJoin.trim());
    if (quiz) {
      navigate(`/quiz/group/join/${quiz.id}`);
    } else {
      setJoinError(translate(UI_STRINGS_KEYS.quizNotFound));
    }
  };

  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';

  const canJoinQuiz = (quiz: GroupQuiz): boolean => {
    const now = new Date();
    const startTime = new Date(quiz.startTime);
    const endTime = new Date(quiz.endTime);
    return now >= startTime && now <= endTime && quiz.status === 'scheduled'; // Or active if status gets updated
  };

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-8 flex justify-between items-center">
           <Button onClick={() => navigate('/')} variant="ghost" size="sm" className="flex items-center">
            <Icon name="arrowRight" className="w-5 h-5 mr-1 transform rotate-180" /> {translate(UI_STRINGS_KEYS.backToDashboard)}
          </Button>
          <h1 className="text-2xl font-bold text-text-heading">{translate(UI_STRINGS_KEYS.quizzesImInvitedTo)}</h1>
          <div></div> {/* Placeholder */}
        </header>

        <div className="mb-8 p-4 bg-card-bg rounded-lg shadow-subtle">
          <h2 className="text-lg font-semibold text-text-heading mb-2">{translate(UI_STRINGS_KEYS.joinWithId)}</h2>
          <div className="flex items-start space-x-2">
            <Input
              id="quizIdToJoin"
              value={quizIdToJoin}
              onChange={(e) => setQuizIdToJoin(e.target.value)}
              placeholder={translate(UI_STRINGS_KEYS.enterQuizIdPrompt)}
              wrapperClassName="flex-grow mb-0"
              error={joinError}
            />
            <Button onClick={handleJoinWithId} className="mt-1">
              {translate(UI_STRINGS_KEYS.joinQuiz)}
            </Button>
          </div>
        </div>

        {invitedQuizzes.length === 0 && !joinError ? (
          <div className="text-center py-10">
            <Icon name="inboxArrowDown" className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-text-main text-lg">{translate(UI_STRINGS_KEYS.noInvitationsYet)}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {invitedQuizzes.map(quiz => {
              const creatorName = "A User"; // Placeholder, would fetch user data in real app
              const alreadyTaken = !!userAttempts[quiz.id];
              const isJoinable = canJoinQuiz(quiz);

              return (
              <div key={quiz.id} className="bg-card-bg p-4 rounded-lg shadow-subtle">
                <h2 className="text-lg font-semibold text-text-heading">{quiz.title}</h2>
                {quiz.description && <p className="text-sm text-text-main mb-1">{quiz.description}</p>}
                <p className="text-xs text-slate-500 mb-1">{translate(UI_STRINGS_KEYS.creator)}: {creatorName}</p>
                <p className="text-xs text-slate-500 mb-2">
                  {translate(UI_STRINGS_KEYS.quizStartsAt, { time: new Date(quiz.startTime).toLocaleString() })} | {translate(UI_STRINGS_KEYS.quizEndsAt, { time: new Date(quiz.endTime).toLocaleString() })}
                </p>
                
                {alreadyTaken ? (
                     <Button size="sm" variant="ghost" disabled>
                        {translate(UI_STRINGS_KEYS.alreadyTakenThisQuiz)} (Score: {userAttempts[quiz.id].score})
                    </Button>
                ) : isJoinable ? (
                  <Button size="sm" variant="primary" onClick={() => navigate(`/quiz/group/join/${quiz.id}`)}>
                    {translate(UI_STRINGS_KEYS.joinQuiz)}
                  </Button>
                ) : (
                   <Button size="sm" variant="outline" disabled>
                     {new Date() < new Date(quiz.startTime) ? translate(UI_STRINGS_KEYS.quizStartsSoon) : translate(UI_STRINGS_KEYS.quizHasEnded)}
                  </Button>
                )}
              </div>
            )})}
          </div>
        )}
      </div>
    </div>
  );
};

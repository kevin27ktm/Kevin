import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../../hooks/useLocalization';
import { Language, Question, QuizConfig, QuizAttempt, AnswerOption, QuizType } from '../../types'; // Added QuizType
import { UI_STRINGS_KEYS } from '../../constants';
import { quizService } from '../../services/quizService';
import { Button } from '../Shared/Button';
import { LoadingSpinner } from '../Shared/LoadingSpinner';
import { Timer } from './Timer';
import { Icon } from '../Shared/Icon';

interface QuizPlayScreenProps {
  config: QuizConfig | null; 
  onQuizComplete: (attempt: QuizAttempt) => void;
}

const defaultQuizConfig: QuizConfig = { 
    books: ['gen', 'mat'], 
    chapters: {},
    numberOfQuestions: 10,
    quizLanguage: Language.ENGLISH,
    quizType: QuizType.PERSONAL, // Added default quizType
};

export const QuizPlayScreen: React.FC<QuizPlayScreenProps> = ({ config, onQuizComplete }) => {
  const { translate, language: uiLanguage } = useLocalization();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswerId, setSelectedAnswerId] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({}); // questionId: selectedAnswerId
  const [isLoading, setIsLoading] = useState(true);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  
  const [quizStartTime, setQuizStartTime] = useState<number>(Date.now());
  const [timeLeftPerQuestion, setTimeLeftPerQuestion] = useState(30); // seconds per question

  const currentQuizConfig = useMemo(() => {
    return config || { ...defaultQuizConfig, quizLanguage: uiLanguage, quizType: QuizType.PERSONAL };
  }, [config, uiLanguage]);


  const loadQuestions = useCallback(async () => {
    setIsLoading(true);
    setApiError(null);
    try {
      const fetchedQuestions = await quizService.generateQuizQuestions(currentQuizConfig);
      if (fetchedQuestions.length === 0) {
        setApiError(translate(UI_STRINGS_KEYS.noQuestionsAvailable));
      } else {
        setQuestions(fetchedQuestions);
      }
      setQuizStartTime(Date.now());
    } catch (error: any) {
      console.error("Failed to load questions:", error);
      setApiError(translate(error.message) || translate(UI_STRINGS_KEYS.errorOccurred)); 
    } finally {
      setIsLoading(false);
    }
  }, [currentQuizConfig, translate]); 

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]); 


  const handleAnswerSelection = (answerId: string) => {
    if (showFeedback) return; 

    setSelectedAnswerId(answerId);
    const currentQuestion = questions[currentQuestionIndex];
    const correctAnswer = currentQuestion.options.find(opt => opt.isCorrect);

    const correct = correctAnswer?.id === answerId;
    setIsCorrect(correct);
    setShowFeedback(true);

    if (correct) {
      setScore(prevScore => prevScore + (currentQuestion.points || 10)); 
    }
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: answerId }));
  };

  const handleNextQuestion = useCallback(() => {
    setShowFeedback(false);
    setSelectedAnswerId(null);
    setIsCorrect(null);
    setTimeLeftPerQuestion(30); 

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      const timeTaken = Math.floor((Date.now() - quizStartTime) / 1000);
      const correctAnswersCount = Object.values(answers).reduce((count, ansId, idx) => {
        if (questions[idx] && questions[idx].options) {
            return questions[idx].options.find(opt => opt.id === ansId)?.isCorrect ? count + 1 : count;
        }
        return count;
      },0);
      const accuracy = questions.length > 0 ? (correctAnswersCount / questions.length) * 100 : 0;
      
      const attempt: QuizAttempt = {
        id: `attempt-${Date.now()}`,
        quizType: currentQuizConfig.quizType || QuizType.PERSONAL, // Ensure quizType is set
        config: currentQuizConfig,
        questions,
        answers,
        score,
        timeTaken,
        accuracy: parseFloat(accuracy.toFixed(1)),
        completedAt: new Date().toISOString(), // Fixed: Convert Date to ISO string
      };
      onQuizComplete(attempt); 
    }
  }, [currentQuestionIndex, questions, answers, score, quizStartTime, currentQuizConfig, onQuizComplete]);
  
  const handleTimeUp = useCallback(() => {
    if (!showFeedback) { 
        setIsCorrect(false); 
        setShowFeedback(true);
        if(questions && questions[currentQuestionIndex]) { 
          setAnswers(prev => ({ ...prev, [questions[currentQuestionIndex].id]: "timeout" })); 
        }
    }
  }, [showFeedback, questions, currentQuestionIndex]);


  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-light-bg">
        <LoadingSpinner text={translate(UI_STRINGS_KEYS.loading)} size="lg" />
      </div>
    );
  }

  if (apiError) {
     return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-light-bg">
        <div className="bg-card-bg p-8 rounded-xl shadow-card">
            <Icon name="xCircle" className="w-16 h-16 text-error mb-4 mx-auto" />
            <p className="text-xl text-text-heading mb-1">{translate(UI_STRINGS_KEYS.errorLoadingQuestion)}</p>
            <p className="text-sm text-text-main mb-4">{apiError}</p>
            <Button onClick={() => navigate('/')}>{translate(UI_STRINGS_KEYS.backToDashboard)}</Button>
        </div>
      </div>
    );
  }
  
  if (questions.length === 0 && !isLoading && !apiError) { 
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-light-bg">
        <div className="bg-card-bg p-8 rounded-xl shadow-card">
            <Icon name="xCircle" className="w-16 h-16 text-slate-400 mb-4 mx-auto" />
            <p className="text-xl text-text-heading mb-4">{translate(UI_STRINGS_KEYS.noQuestionsAvailable)}</p>
            <Button onClick={() => navigate('/')}>{translate(UI_STRINGS_KEYS.backToDashboard)}</Button>
        </div>
      </div>
    );
  }
  
  if (!questions[currentQuestionIndex]) {
    return (
         <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-light-bg">
            <div className="bg-card-bg p-8 rounded-xl shadow-card">
                <Icon name="xCircle" className="w-16 h-16 text-error mb-4 mx-auto" />
                <p className="text-xl text-text-heading mb-4">{translate(UI_STRINGS_KEYS.errorLoadingQuestion)}</p>
                <p className="text-sm text-text-main mb-4">{translate(UI_STRINGS_KEYS.noQuestionsAvailable)}</p>
                <Button onClick={() => navigate('/')}>{translate(UI_STRINGS_KEYS.backToDashboard)}</Button>
            </div>
        </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const quizLangFontClass = currentQuizConfig.quizLanguage === Language.MALAYALAM ? 'font-malayalam' : '';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center bg-light-bg p-4 ${quizLangFontClass}`}>
      <div className="w-full max-w-2xl bg-card-bg p-6 md:p-8 rounded-xl shadow-card">
        {/* Header Bar */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-border-color">
          <div>
            <span className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.question)} {currentQuestionIndex + 1}/{questions.length}</span>
            <p className="text-lg font-semibold text-primary">{translate(UI_STRINGS_KEYS.points)}: {score}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.timer)}</p>
            <Timer 
                key={currentQuestionIndex}
                initialTime={timeLeftPerQuestion} 
                onTimeUp={handleTimeUp} 
                isPaused={showFeedback}
            />
          </div>
        </div>

        {/* Question Display Area */}
        <div className="mb-6 min-h-[6rem]"> {/* Added min-height to reduce layout shift */}
          <h2 className="text-xl md:text-2xl font-semibold text-text-heading mb-2">{currentQuestion.text}</h2>
          {currentQuestion.reference && (
            <p className="text-xs text-slate-500 italic">({currentQuestion.reference})</p>
          )}
        </div>

        {/* Answer Options */}
        <div className="space-y-3 mb-6">
          {(currentQuestion.options || []).map((option) => { // Added || [] for safety
            let buttonClass = "w-full text-left p-3 border rounded-lg transition-all duration-200 ease-in-out font-medium ";
            if (showFeedback) {
              if (option.isCorrect) {
                buttonClass += "bg-emerald-50 border-success text-emerald-700 ring-2 ring-success";
              } else if (selectedAnswerId === option.id && !option.isCorrect) {
                buttonClass += "bg-rose-50 border-error text-rose-700 ring-2 ring-error";
              } else {
                 buttonClass += "bg-slate-100 border-border-color text-slate-500 opacity-70 cursor-not-allowed";
              }
            } else if (selectedAnswerId === option.id) {
                 buttonClass += "bg-sky-50 border-primary text-primary ring-2 ring-primary";
            } else {
                 buttonClass += "bg-slate-50 hover:bg-sky-50 border-border-color hover:border-primary text-text-main hover:text-primary";
            }
            return (
              <button
                key={option.id}
                onClick={() => handleAnswerSelection(option.id)}
                disabled={showFeedback}
                className={buttonClass}
                aria-pressed={selectedAnswerId === option.id}
              >
                {option.text}
              </button>
            );
          })}
        </div>
        
        {/* Feedback and Next Button */}
        {showFeedback && (
          <div className="text-center mb-4 p-3 rounded-md min-h-[6rem]"> {/* Added min-height */}
            {isCorrect === true && (
                <div className="flex items-center justify-center text-success">
                    <Icon name="checkCircle" className="w-6 h-6 mr-2"/>
                    <p className="text-lg font-semibold">{translate(UI_STRINGS_KEYS.correct)}</p>
                </div>
            )}
            {isCorrect === false && (
                <div className="flex items-center justify-center text-error">
                    <Icon name="xCircle" className="w-6 h-6 mr-2"/>
                    <p className="text-lg font-semibold">{translate(UI_STRINGS_KEYS.incorrect)}</p>
                </div>
            )}
            <Button onClick={handleNextQuestion} fullWidth className="mt-4">
              {currentQuestionIndex < questions.length - 1 ? translate(UI_STRINGS_KEYS.nextQuestion) : translate(UI_STRINGS_KEYS.quizResults)}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../../hooks/useLocalization';
import { Language, QuizAttempt } from '../../types';
import { UI_STRINGS_KEYS } from '../../constants';
import { Button } from '../Shared/Button';
import { Icon, IconName } from '../Shared/Icon';

interface QuizResultsScreenProps {
  attempt: QuizAttempt;
  onPlayAgain: (config: QuizAttempt['config']) => void;
  // onNavigate removed
}

const ResultStat: React.FC<{ label: string; value: string | number; iconName?: IconName }> = ({ label, value, iconName }) => (
  <div className="bg-slate-50 border border-border-color p-4 rounded-lg text-center shadow-subtle">
    {iconName && <Icon name={iconName} className="w-8 h-8 mx-auto mb-2 text-primary" />}
    <p className="text-sm text-text-main mb-1">{label}</p>
    <p className="text-2xl font-bold text-text-heading">{value}</p>
  </div>
);

export const QuizResultsScreen: React.FC<QuizResultsScreenProps> = ({ attempt, onPlayAgain }) => {
  const { translate, language } = useLocalization();
  const navigate = useNavigate();

  const totalQuestions = attempt.questions.length;
  const correctCount = Object.values(attempt.answers).filter((ansId, index) => 
    attempt.questions[index].options.find(opt => opt.id === ansId)?.isCorrect
  ).length;
  const incorrectCount = totalQuestions - correctCount;

  const performanceMessageKey = attempt.accuracy >= 80 
    ? UI_STRINGS_KEYS.excellent 
    : UI_STRINGS_KEYS.keepGoing;

  const formatTime = (seconds: number): string => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    const minText = translate(UI_STRINGS_KEYS.timeUnitMinutes);
    const secText = translate(UI_STRINGS_KEYS.timeUnitSeconds);
    return `${min}${minText} ${sec}${secText}`;
  };

  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';


  return (
    <div className={`min-h-screen flex flex-col items-center justify-center bg-light-bg p-4 ${currentFontClass}`}>
      <div className="w-full max-w-2xl bg-card-bg p-6 md:p-8 rounded-xl shadow-card text-center">
        <Icon name={attempt.accuracy >= 50 ? "checkCircle" : "xCircle"} className={`w-20 h-20 mx-auto mb-4 ${attempt.accuracy >= 50 ? 'text-success' : 'text-error' }`} />
        
        <h1 className="text-3xl font-bold text-text-heading mb-2">
          {translate(UI_STRINGS_KEYS.quizResults)}
        </h1>
        <p className="text-lg text-secondary mb-6">{translate(performanceMessageKey)}</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <ResultStat label={translate(UI_STRINGS_KEYS.totalScore)} value={attempt.score} iconName="bookOpen" />
          <ResultStat label={translate(UI_STRINGS_KEYS.correctAnswers)} value={correctCount} iconName="checkCircle" />
          <ResultStat label={translate(UI_STRINGS_KEYS.incorrectAnswers)} value={incorrectCount} iconName="xCircle" />
          <ResultStat label={translate(UI_STRINGS_KEYS.accuracy)} value={`${attempt.accuracy}%`} iconName="lightBulb" />
        </div>
        <ResultStat label={translate(UI_STRINGS_KEYS.timeTaken)} value={formatTime(attempt.timeTaken)} iconName="cog" />


        <div className="mt-8 space-y-3 sm:space-y-0 sm:flex sm:flex-wrap sm:justify-center sm:gap-4">
          <Button onClick={() => onPlayAgain(attempt.config)} variant="primary" size="lg" className="w-full sm:w-auto">
            {translate(UI_STRINGS_KEYS.playAgain)}
          </Button>
          <Button onClick={() => navigate('/quiz/customize')} variant="secondary" size="lg" className="w-full sm:w-auto">
            {translate(UI_STRINGS_KEYS.customizeNewQuiz)}
          </Button>
          <Button onClick={() => navigate('/')} variant="outline" size="lg" className="w-full sm:w-auto">
            {translate(UI_STRINGS_KEYS.backToDashboard)}
          </Button>
        </div>
        
        {/* Review Answers Button - Future Implementation
        <div className="mt-6">
            <Button variant="ghost" onClick={() => alert("Review Answers feature coming soon!")}>
            {translate(UI_STRINGS_KEYS.reviewAnswers)}
            </Button>
        </div>
        */}
         {/* Share Score Button - Future Implementation
        <div className="mt-6">
            <Button variant="ghost" onClick={() => alert("Share Score feature coming soon!")}>
            {translate(UI_STRINGS_KEYS.shareScore)}
            </Button>
        </div>
        */}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';

interface TimerProps {
  initialTime: number; // seconds
  onTimeUp: () => void;
  isPaused: boolean;
  onTick?: (remainingTime: number) => void; 
}

export const Timer: React.FC<TimerProps> = ({ initialTime, onTimeUp, isPaused, onTick }) => {
  const [remainingTime, setRemainingTime] = useState(initialTime);

  useEffect(() => {
    setRemainingTime(initialTime); // Reset timer when initialTime changes (e.g. new question)
  }, [initialTime]);

  useEffect(() => {
    if (isPaused || remainingTime <= 0) {
      if (remainingTime <= 0) {
        onTimeUp();
      }
      return;
    }

    const intervalId = setInterval(() => {
      setRemainingTime(prevTime => {
        const newTime = prevTime - 1;
        if (onTick) {
            onTick(newTime);
        }
        if (newTime <= 0) {
          clearInterval(intervalId);
          onTimeUp();
          return 0;
        }
        return newTime;
      });
    }, 1000);

    return () => clearInterval(intervalId);
  }, [remainingTime, onTimeUp, isPaused, onTick]);

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const timeColorClass = remainingTime <= 10 ? 'text-red-500' : 'text-text-heading';

  return (
    <div className={`text-xl font-semibold ${timeColorClass}`}>
      {formatTime(remainingTime)}
    </div>
  );
};

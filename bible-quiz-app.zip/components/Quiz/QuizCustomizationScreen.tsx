
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../../hooks/useLocalization';
import { Language, BibleBook, BibleChapter, QuizConfig, QuizType, QuizDifficulty } from '../../types';
import { UI_STRINGS_KEYS, DEFAULT_QUIZ_SETTINGS } from '../../constants';
import { BIBLE_BOOKS_DATA } from '../../utils/bibleData';
import { Button } from '../Shared/Button';
import { Icon } from '../Shared/Icon';

interface PersonalQuizCustomizationScreenProps {
  onStartQuiz: (config: QuizConfig) => void;
}

export const PersonalQuizCustomizationScreen: React.FC<PersonalQuizCustomizationScreenProps> = ({ onStartQuiz }) => {
  const { translate, language: uiLanguage } = useLocalization(); // Removed setUiLanguage as quiz content lang is separate
  const navigate = useNavigate();
  
  const [selectedBookIds, setSelectedBookIds] = useState<string[]>([]);
  const [selectedChapters, setSelectedChapters] = useState<Record<string, number[]>>({});
  const [numberOfQuestions, setNumberOfQuestions] = useState<number>(DEFAULT_QUIZ_SETTINGS.numberOfQuestions);
  const [quizContentLanguage, setQuizContentLanguage] = useState<Language>(DEFAULT_QUIZ_SETTINGS.language);
  // Difficulty is optional for personal, can default to mixed or not be shown if not used by personal quiz generator
  const [difficulty, setDifficulty] = useState<QuizDifficulty>(DEFAULT_QUIZ_SETTINGS.difficulty);


  const [expandedBook, setExpandedBook] = useState<string | null>(null);

  useEffect(() => {
    setQuizContentLanguage(uiLanguage);
  }, [uiLanguage]);

  const handleBookSelection = (bookId: string) => {
    setSelectedBookIds(prev => 
      prev.includes(bookId) ? prev.filter(id => id !== bookId) : [...prev, bookId]
    );
    if (selectedBookIds.includes(bookId)) {
      setSelectedChapters(prev => {
        const newState = {...prev};
        delete newState[bookId];
        return newState;
      });
    }
  };

  const handleChapterSelection = (bookId: string, chapterNumber: number) => {
    setSelectedChapters(prev => {
      const currentBookChapters = prev[bookId] || [];
      const newBookChapters = currentBookChapters.includes(chapterNumber)
        ? currentBookChapters.filter(cn => cn !== chapterNumber)
        : [...currentBookChapters, chapterNumber];
      return { ...prev, [bookId]: newBookChapters };
    });
  };

  const handleSelectAllChapters = (bookId: string) => {
    const book = BIBLE_BOOKS_DATA.find(b => b.id === bookId);
    if (!book) return;
    const allChapterNumbers = book.chapters.map(c => c.chapterNumber);
    setSelectedChapters(prev => ({ ...prev, [bookId]: allChapterNumbers }));
  };

  const handleSelectAllBooks = (testament?: 'OT' | 'NT') => {
    const booksToSelect = BIBLE_BOOKS_DATA
        .filter(b => !testament || b.testament === testament)
        .map(b => b.id);
    setSelectedBookIds(booksToSelect);
  };
  
  const handleToggleExpandBook = (bookId: string) => {
    setExpandedBook(prev => prev === bookId ? null : bookId);
  };

  const handleSubmit = () => {
    if (selectedBookIds.length === 0) {
        alert(translate(UI_STRINGS_KEYS.pleaseSelectBooks)); 
        return;
    }
    const config: QuizConfig = {
      books: selectedBookIds,
      chapters: selectedChapters,
      numberOfQuestions,
      quizLanguage: quizContentLanguage,
      difficulty: difficulty, // Add difficulty
      quizType: QuizType.PERSONAL,
    };
    onStartQuiz(config);
  };

  const renderBookList = (testament: 'OT' | 'NT') => {
    return BIBLE_BOOKS_DATA
      .filter(book => book.testament === testament)
      .map(book => (
        <div key={book.id} className="mb-2 p-3 bg-slate-50 border border-border-color rounded-lg">
          <div className="flex items-center justify-between">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-primary rounded focus:ring-primary focus:ring-offset-1"
                checked={selectedBookIds.includes(book.id)}
                onChange={() => handleBookSelection(book.id)}
              />
              <span className="font-medium text-text-main">{uiLanguage === Language.MALAYALAM ? book.nameMl : book.name}</span>
            </label>
            {selectedBookIds.includes(book.id) && (
              <Button size="sm" variant="ghost" onClick={() => handleToggleExpandBook(book.id)} className="!px-2">
                {translate(UI_STRINGS_KEYS.chooseChapters)} {expandedBook === book.id ? '▲' : '▼'}
              </Button>
            )}
          </div>
          {selectedBookIds.includes(book.id) && expandedBook === book.id && (
            <div className="mt-3 pt-3 pl-4 border-l-2 border-primary/30">
              <div className="mb-2">
                <Button size="sm" variant="outline" onClick={() => handleSelectAllChapters(book.id)} className="mr-2">
                  {translate(UI_STRINGS_KEYS.allChapters)}
                </Button>
                <Button size="sm" variant="outline" onClick={() => setSelectedChapters(prev => ({...prev, [book.id]:[]}))} >
                  {translate(UI_STRINGS_KEYS.deselectAll)}
                </Button>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                {book.chapters.map(chapter => (
                  <label key={chapter.id} className="flex items-center space-x-1 p-1.5 border border-slate-200 rounded-md hover:bg-sky-50 cursor-pointer text-sm">
                    <input
                      type="checkbox"
                      className="form-checkbox h-4 w-4 text-primary rounded focus:ring-primary focus:ring-offset-0"
                      checked={(selectedChapters[book.id] || []).includes(chapter.chapterNumber)}
                      onChange={() => handleChapterSelection(book.id, chapter.chapterNumber)}
                    />
                    <span>{chapter.chapterNumber}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      ));
  };
  
  const currentFontClass = uiLanguage === Language.MALAYALAM ? 'font-malayalam' : '';

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-8 flex justify-between items-center">
          <Button onClick={() => navigate('/')} variant="ghost" size="sm" className="flex items-center">
            <Icon name="arrowRight" className="w-5 h-5 mr-1 transform rotate-180" /> {translate(UI_STRINGS_KEYS.backToDashboard)}
          </Button>
          <h1 className="text-2xl font-bold text-text-heading">{translate(UI_STRINGS_KEYS.customizePersonalQuiz)}</h1>
          <div></div> {/* Placeholder */}
        </header>

        <div className="bg-card-bg p-6 sm:p-8 rounded-xl shadow-card space-y-8">
          <section>
            <h2 className="text-xl font-semibold text-text-heading mb-3">{translate(UI_STRINGS_KEYS.chooseBibleBooks)}</h2>
            <div className="mb-4 space-x-2">
              <Button size="sm" variant="outline" onClick={() => handleSelectAllBooks('OT')}>{translate(UI_STRINGS_KEYS.oldTestament)} ({translate(UI_STRINGS_KEYS.selectAll)})</Button>
              <Button size="sm" variant="outline" onClick={() => handleSelectAllBooks('NT')}>{translate(UI_STRINGS_KEYS.newTestament)} ({translate(UI_STRINGS_KEYS.selectAll)})</Button>
              <Button size="sm" variant="outline" onClick={() => setSelectedBookIds([])}>{translate(UI_STRINGS_KEYS.deselectAllBooks)}</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium text-text-main mb-2">{translate(UI_STRINGS_KEYS.oldTestament)}</h3>
                <div className="max-h-96 overflow-y-auto pr-2 custom-scrollbar space-y-2">{renderBookList('OT')}</div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-text-main mb-2">{translate(UI_STRINGS_KEYS.newTestament)}</h3>
                <div className="max-h-96 overflow-y-auto pr-2 custom-scrollbar space-y-2">{renderBookList('NT')}</div>
              </div>
            </div>
          </section>

          <section>
            <label htmlFor="numQuestions" className="block text-xl font-semibold text-text-heading mb-2">
              {translate(UI_STRINGS_KEYS.numberOfQuestions)}: <span className="text-primary">{numberOfQuestions}</span>
            </label>
            <input
              id="numQuestions"
              type="range"
              min="5"
              max="50"
              step="5"
              value={numberOfQuestions}
              onChange={(e) => setNumberOfQuestions(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
            />
            <div className="flex justify-between text-xs text-text-main mt-1">
              <span>5</span>
              <span>50</span>
            </div>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-text-heading mb-2">{translate(UI_STRINGS_KEYS.difficultyLevel)}</h2>
            <div className="flex flex-wrap gap-3">
              {(Object.values(QuizDifficulty) as QuizDifficulty[]).map(level => (
                <label key={level} className="flex items-center space-x-2 cursor-pointer p-2 border border-border-color rounded-md hover:border-primary has-[:checked]:bg-sky-50 has-[:checked]:border-primary">
                  <input
                    type="radio"
                    name="difficulty"
                    className="form-radio h-4 w-4 text-primary focus:ring-primary focus:ring-offset-1"
                    checked={difficulty === level}
                    onChange={() => setDifficulty(level)}
                  />
                  <span className={`text-text-main`}>
                    {translate(level)}
                  </span>
                </label>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-text-heading mb-2">{translate(UI_STRINGS_KEYS.quizLanguage)}</h2>
            <div className="flex space-x-4">
              {(Object.values(Language) as Language[]).map(lang => (
                <label key={lang} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="quizLanguage"
                    className="form-radio h-5 w-5 text-primary focus:ring-primary focus:ring-offset-1"
                    checked={quizContentLanguage === lang}
                    onChange={() => setQuizContentLanguage(lang)}
                  />
                  <span className={`text-text-main ${lang === Language.MALAYALAM ? 'font-malayalam' : ''}`}>
                    {translate(lang === Language.ENGLISH ? UI_STRINGS_KEYS.english : UI_STRINGS_KEYS.malayalam)}
                  </span>
                </label>
              ))}
            </div>
          </section>

          <Button onClick={handleSubmit} fullWidth size="lg">
            {translate(UI_STRINGS_KEYS.startPersonalQuiz)}
          </Button>
        </div>
      </div>
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
            width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #e2e8f0; /* slate-200 */
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #0284c7; /* primary color: sky-600 */
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #0369a1; /* primary-hover color: sky-700 */
        }
      `}} />
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useLocalization } from '../../hooks/useLocalization';
import { UI_STRINGS_KEYS, LOCAL_STORAGE_KEYS } from '../../constants';
import { QuizAttempt, Language } from '../../types'; // Imported Language
import { Button } from '../Shared/Button';
import { Input } from '../Shared/Input';
import { Icon } from '../Shared/Icon';

export const ProfileScreen: React.FC = () => {
  const { currentUser, updateCurrentUser, logout, isLoading: authLoading } = useAuth();
  const { translate, language } = useLocalization();
  const navigate = useNavigate();

  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [isEditing, setIsEditing] = useState(false);
  const [quizzesTaken, setQuizzesTaken] = useState(0);
  const [averageScore, setAverageScore] = useState(0);

  useEffect(() => {
    if (currentUser?.displayName) {
      setDisplayName(currentUser.displayName);
    }
    // Load stats from localStorage (simplified)
    try {
      const attemptsStr = localStorage.getItem(LOCAL_STORAGE_KEYS.QUIZ_ATTEMPTS);
      if (attemptsStr && currentUser) {
        const allAttempts: QuizAttempt[] = JSON.parse(attemptsStr);
        const userAttempts = allAttempts.filter(attempt => attempt.userId === currentUser.id);
        setQuizzesTaken(userAttempts.length);
        if (userAttempts.length > 0) {
          const totalScore = userAttempts.reduce((sum, attempt) => sum + attempt.score, 0);
          setAverageScore(parseFloat((totalScore / userAttempts.length).toFixed(1)));
        }
      }
    } catch (e) {
      console.error("Error loading quiz attempts for profile stats:", e);
    }
  }, [currentUser]);

  const handleUpdateProfile = () => {
    if (!currentUser || !displayName.trim()) return;
    updateCurrentUser({ displayName: displayName.trim() });
    setIsEditing(false);
    alert(translate(UI_STRINGS_KEYS.profileUpdatedSuccess));
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{translate(UI_STRINGS_KEYS.loading)}...</p>
      </div>
    );
  }
  
  const currentFontClass = language === Language.MALAYALAM ? 'font-malayalam' : '';

  return (
    <div className={`min-h-screen bg-light-bg ${currentFontClass}`}>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-8 flex justify-between items-center">
          <Button onClick={() => navigate('/')} variant="ghost" size="sm" className="flex items-center">
            <Icon name="arrowRight" className="w-5 h-5 mr-1 transform rotate-180" /> {translate(UI_STRINGS_KEYS.backToDashboard)}
          </Button>
          <h1 className="text-2xl font-bold text-text-heading">{translate(UI_STRINGS_KEYS.profile)}</h1>
          <Button onClick={handleLogout} variant="danger" size="sm" isLoading={authLoading}>
            {translate(UI_STRINGS_KEYS.logout)}
          </Button>
        </header>

        <div className="bg-card-bg p-6 sm:p-8 rounded-xl shadow-card">
          <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 mb-8 pb-8 border-b border-border-color">
            <div className="flex-shrink-0">
              {/* Placeholder for profile picture */}
              <div className="h-24 w-24 rounded-full bg-primary flex items-center justify-center text-white text-4xl font-bold">
                {currentUser.displayName ? currentUser.displayName.charAt(0).toUpperCase() : currentUser.email.charAt(0).toUpperCase()}
              </div>
            </div>
            <div className="flex-grow text-center sm:text-left">
              {isEditing ? (
                <div className="flex items-center gap-2">
                   <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder={translate(UI_STRINGS_KEYS.displayNamePlaceholder)}
                    wrapperClassName="mb-0 flex-grow"
                    className="text-2xl"
                  />
                  <Button onClick={handleUpdateProfile} size="sm">{translate(UI_STRINGS_KEYS.save)}</Button>
                  <Button onClick={() => {setIsEditing(false); setDisplayName(currentUser.displayName || '');}} variant="outline" size="sm">{translate(UI_STRINGS_KEYS.cancel)}</Button>
                </div>
              ) : (
                <>
                  <h2 className="text-2xl font-bold text-text-heading">{currentUser.displayName || 'User'}</h2>
                  <p className="text-text-main">{currentUser.email}</p>
                  <Button onClick={() => setIsEditing(true)} variant="ghost" size="sm" className="mt-1 !px-1 text-primary">
                    <Icon name="pencil" className="w-4 h-4 mr-1 inline"/> {translate(UI_STRINGS_KEYS.editProfile)}
                  </Button>
                </>
              )}
            </div>
          </div>

          <section>
            <h3 className="text-xl font-semibold text-text-heading mb-4">{translate(UI_STRINGS_KEYS.myStats)}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg shadow-subtle">
                <Icon name="listBullet" className="w-8 h-8 text-primary mb-2" />
                <p className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.quizzesTaken)}</p>
                <p className="text-3xl font-bold text-text-heading">{quizzesTaken}</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg shadow-subtle">
                <Icon name="checkCircle" className="w-8 h-8 text-primary mb-2" />
                <p className="text-sm text-text-main">{translate(UI_STRINGS_KEYS.averageScore)}</p>
                <p className="text-3xl font-bold text-text-heading">{averageScore.toFixed(1)}</p>
              </div>
            </div>
          </section>
          {/* More stats can be added here: High scores, favorite topics etc. */}
        </div>
      </div>
    </div>
  );
};

import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { User } from '../types';
import { LOCAL_STORAGE_KEYS } from '../constants';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<User | null>; // Pass is conceptual for local
  signup: (email: string, pass: string, displayName: string) => Promise<User | null>; // Pass is conceptual
  logout: () => Promise<void>;
  updateCurrentUser: (userData: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data storage (replace with actual API calls in a real app)
const MOCK_USERS_DB_KEY = 'bibleQuizApp_usersDB';

const getMockUsers = (): Record<string, User> => {
  try {
    const users = localStorage.getItem(MOCK_USERS_DB_KEY);
    return users ? JSON.parse(users) : {};
  } catch (e) {
    return {};
  }
};

const saveMockUsers = (users: Record<string, User>) => {
  localStorage.setItem(MOCK_USERS_DB_KEY, JSON.stringify(users));
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Try to load user from local storage on initial load
    try {
      const storedUser = localStorage.getItem(LOCAL_STORAGE_KEYS.USER);
      if (storedUser) {
        setCurrentUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Error parsing stored user:", error);
      localStorage.removeItem(LOCAL_STORAGE_KEYS.USER);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = useCallback(async (email: string, _pass: string): Promise<User | null> => {
    setIsLoading(true);
    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        const users = getMockUsers();
        const foundUser = Object.values(users).find(u => u.email === email);
        
        if (foundUser) {
          // In a real app, you'd verify the password hash here
          setCurrentUser(foundUser);
          localStorage.setItem(LOCAL_STORAGE_KEYS.USER, JSON.stringify(foundUser));
          resolve(foundUser);
        } else {
          resolve(null); // User not found or password incorrect
        }
        setIsLoading(false);
      }, 500);
    });
  }, []);

  const signup = useCallback(async (email: string, _pass: string, displayName: string): Promise<User | null> => {
    setIsLoading(true);
    return new Promise((resolve) => {
      setTimeout(() => {
        const users = getMockUsers();
        if (Object.values(users).some(u => u.email === email)) {
          resolve(null); // User already exists
          setIsLoading(false);
          return;
        }

        const newUser: User = {
          id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          email,
          displayName,
          createdAt: new Date().toISOString(),
        };
        users[newUser.id] = newUser;
        saveMockUsers(users);
        // setCurrentUser(newUser); // Typically, user logs in after signup
        // localStorage.setItem(LOCAL_STORAGE_KEYS.USER, JSON.stringify(newUser));
        resolve(newUser); // Or just resolve true/false and redirect to login
        setIsLoading(false);
      }, 500);
    });
  }, []);

  const logout = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        setCurrentUser(null);
        localStorage.removeItem(LOCAL_STORAGE_KEYS.USER);
        resolve();
        setIsLoading(false);
      }, 300);
    });
  }, []);
  
  const updateCurrentUser = useCallback((userData: Partial<User>) => {
    setCurrentUser(prevUser => {
      if (!prevUser) return null;
      const updatedUser = { ...prevUser, ...userData, id: prevUser.id, email: prevUser.email }; // Ensure ID and email are not overwritten by partial update
      localStorage.setItem(LOCAL_STORAGE_KEYS.USER, JSON.stringify(updatedUser));
      
      // Also update in mock users DB
      const users = getMockUsers();
      if (users[updatedUser.id]) {
        users[updatedUser.id] = updatedUser;
        saveMockUsers(users);
      }
      return updatedUser;
    });
  }, []);


  return (
    <AuthContext.Provider value={{ currentUser, isAuthenticated: !!currentUser, isLoading, login, signup, logout, updateCurrentUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

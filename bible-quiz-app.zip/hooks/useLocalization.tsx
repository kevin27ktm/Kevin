
import React, { createContext, useState, useContext, useCallback, ReactNode } from 'react';
import { Language, TranslationSet } from '../types';
import { TRANSLATIONS, UI_STRINGS_KEYS } from '../constants';

interface LocalizationContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  translate: (key: string, substitutions?: Record<string, string>) => string;
  currentStrings: TranslationSet;
}

const LocalizationContext = createContext<LocalizationContextType | undefined>(undefined);

export const LocalizationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);

  const translate = useCallback((key: string, substitutions?: Record<string, string>): string => {
    let translatedString = TRANSLATIONS[language][key] || key;
    if (substitutions) {
      Object.keys(substitutions).forEach(subKey => {
        translatedString = translatedString.replace(`{{${subKey}}}`, substitutions[subKey]);
      });
    }
    return translatedString;
  }, [language]);

  const currentStrings = TRANSLATIONS[language];

  return (
    <LocalizationContext.Provider value={{ language, setLanguage, translate, currentStrings }}>
      {children}
    </LocalizationContext.Provider>
  );
};

export const useLocalization = (): LocalizationContextType => {
  const context = useContext(LocalizationContext);
  if (!context) {
    throw new Error('useLocalization must be used within a LocalizationProvider');
  }
  return context;
};
